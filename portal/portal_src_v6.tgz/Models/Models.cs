namespace InfoSistemas.Portal.Models;

/// <summary>Loja/empresa cliente (1 CNPJ = 1 loja com seu túnel próprio).</summary>
public class Cliente
{
    public int Id { get; set; }
    public string Cnpj { get; set; } = "";
    public string RazaoSocial { get; set; } = "";
    public bool Ativo { get; set; } = true;

    /// <summary>Host interno do túnel no servidor (normalmente 127.0.0.1).</summary>
    public string TunnelHost { get; set; } = "127.0.0.1";
    /// <summary>Porta remota que o frpc da loja expõe no broker para a API de relatórios.</summary>
    public int TunnelPort { get; set; }

    /// <summary>Chave de ativacao usada pelo Retaguarda para autoconfigurar a nuvem.</summary>
    public string? ChaveAtivacao { get; set; }

    public DateTime CriadoEm { get; set; }
}

/// <summary>Usuário de acesso ao portal. Admin tem FkCliente nulo e vê todos.</summary>
public class Usuario
{
    public int Id { get; set; }
    public int? FkCliente { get; set; }
    public string Login { get; set; } = "";
    public string SenhaHash { get; set; } = "";
    public string Nome { get; set; } = "";
    public bool IsAdmin { get; set; }
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; }

    // join helpers
    public string? ClienteCnpj { get; set; }
    public string? ClienteRazao { get; set; }
}

/// <summary>Definição de um relatório disponível no portal.</summary>
public record RelatorioInfo(string Codigo, string Titulo, string Descricao, string Categoria);
