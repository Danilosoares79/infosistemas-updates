using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[Authorize]
public class IndexModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public IndexModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public string Loja { get; private set; } = "";
    public List<CatalogoItem> Relatorios { get; private set; } = new();
    public string? Aviso { get; private set; }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true"))
            return RedirectToPage("/Admin/Index");

        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;

        if (cliente == null || cliente.TunnelPort <= 0)
        {
            Aviso = "O canal de dados desta loja ainda não foi configurado. Fale com o suporte.";
            return Page();
        }

        Relatorios = await _api.CatalogoAsync(cliente.TunnelPort);
        if (Relatorios.Count == 0)
            Aviso = "A loja está offline no momento (sistema fechado ou sem internet). " +
                    "Os relatórios aparecem assim que a loja estiver conectada.";
        return Page();
    }
}
