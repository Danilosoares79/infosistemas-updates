using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages.Admin;

[Authorize(Policy = "AdminOnly")]
public class IndexModel : PageModel
{
    private readonly Db _db;
    public IndexModel(Db db) => _db = db;

    public List<Cliente> Clientes { get; private set; } = new();
    public List<Usuario> Usuarios { get; private set; } = new();
    [TempData] public string? Msg { get; set; }
    [TempData] public string? MsgErro { get; set; }

    public async Task OnGetAsync() => await CarregarAsync();

    private async Task CarregarAsync()
    {
        Clientes = await _db.ListarClientesAsync();
        Usuarios = await _db.ListarUsuariosAsync();
    }

    public async Task<IActionResult> OnPostNovoClienteAsync(string cnpj, string razao, int tunnelPort)
    {
        var dig = Db.SoDigitos(cnpj);
        if (dig.Length != 14 && dig.Length != 11)
        {
            MsgErro = "Documento inválido: informe um CNPJ (14 dígitos) ou CPF (11 dígitos).";
            return RedirectToPage();
        }
        await _db.SalvarClienteAsync(new Cliente
        {
            Cnpj = dig,
            RazaoSocial = (razao ?? "").Trim(),
            Ativo = true,
            TunnelPort = tunnelPort,
        });
        Msg = "Loja cadastrada.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostNovoUsuarioAsync(int clienteId, string login, string senha, string nome)
    {
        if (clienteId <= 0 || string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(senha))
        {
            MsgErro = "Preencha loja, usuário e senha.";
            return RedirectToPage();
        }
        try
        {
            await _db.CriarUsuarioAsync(clienteId, login.Trim(), senha, (nome ?? "").Trim(), false);
            Msg = "Usuário criado.";
        }
        catch
        {
            MsgErro = "Não foi possível criar (login já existe para essa loja?).";
        }
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostResetSenhaAsync(int usuarioId, string novaSenha)
    {
        if (string.IsNullOrWhiteSpace(novaSenha))
        {
            MsgErro = "Informe a nova senha.";
            return RedirectToPage();
        }
        await _db.RedefinirSenhaAsync(usuarioId, novaSenha);
        Msg = "Senha redefinida.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostToggleUsuarioAsync(int usuarioId, bool ativo)
    {
        await _db.DefinirAtivoUsuarioAsync(usuarioId, ativo);
        Msg = ativo ? "Usuário ativado." : "Usuário desativado.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditarClienteAsync(int id, string razao, bool ativo, int tunnelPort)
    {
        if (string.IsNullOrWhiteSpace(razao)) { MsgErro = "Razão social é obrigatória."; return RedirectToPage(); }
        await _db.AtualizarClienteAsync(id, razao, ativo, tunnelPort);
        Msg = "Loja atualizada.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditarUsuarioAsync(int id, string login, string nome)
    {
        if (string.IsNullOrWhiteSpace(login)) { MsgErro = "Usuário é obrigatório."; return RedirectToPage(); }
        try { await _db.AtualizarUsuarioAsync(id, login, nome); Msg = "Usuário atualizado."; }
        catch { MsgErro = "Não foi possível atualizar (login já existe para essa loja?)."; }
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostAdminSenhaAsync(string novaSenha)
    {
        if (string.IsNullOrWhiteSpace(novaSenha) || novaSenha.Trim().Length < 6)
        { MsgErro = "A senha do admin precisa de pelo menos 6 caracteres."; return RedirectToPage(); }
        await _db.AlterarSenhaAdminAsync(novaSenha.Trim());
        Msg = "Senha do admin alterada com sucesso.";
        return RedirectToPage();
    }
}
