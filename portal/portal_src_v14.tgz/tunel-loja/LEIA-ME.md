# Agente de Túnel da Loja (frpc)

Conecta a **API local da loja** (porta 5000, `InfoSistemas.Api`) ao **Portal de
Relatórios** na AWS, por túnel reverso FRP. A loja "disca para fora" — nada é
aberto na internet da loja.

## Pré-requisitos
- A `InfoSistemas.Api` rodando na loja (porta 5000) com a versão que inclui os
  endpoints `/api/relatorios/*` e o token configurado em `appsettings.json`:
  ```json
  "Portal": { "Token": "MESMO_TOKEN_DO_PORTAL" }
  ```
- Token do broker FRP (do servidor, em `/opt/infosistemas/portal/secrets.env`).
- Uma **porta remota exclusiva** por loja (ex.: 16001, 16002, ...).

## Instalação (na máquina servidora da loja, PowerShell como Admin)
```powershell
.\INSTALAR_TUNEL.ps1 -Cnpj "00000000000000" -RemotePort 16001 -Token "TOKEN_DO_BROKER"
```
O script baixa o `frpc`, grava `C:\InfoSistemas\tunel\frpc.toml`, registra a tarefa
de inicialização **InfoSistemas-Tunel** (sobe no boot e reinicia em caso de queda)
e inicia o túnel.

## No Portal (admin)
Cadastre a loja com **Porta túnel = RemotePort** (ex.: 16001). O portal passa a
alcançar a API da loja em `127.0.0.1:16001` (lado servidor), em tempo real.

## Conferência
- Na loja: `Get-ScheduledTask InfoSistemas-Tunel` deve estar *Running*.
- No servidor: `sudo docker logs portal-frps-1` mostra a conexão do proxy
  `loja-<cnpj>-api`.

## Segurança
- O túnel é autenticado pelo token do broker (FRP).
- Os endpoints de relatório exigem o header `X-Portal-Token` (só o portal envia).
- Somente leitura — nenhuma escrita no banco da loja.
