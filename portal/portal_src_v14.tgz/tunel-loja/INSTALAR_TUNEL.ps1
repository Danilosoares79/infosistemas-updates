<#  ============================================================
    InfoSistemas - Agente de Tunel (frpc) da Loja
    ------------------------------------------------------------
    Conecta a API local da loja (porta 5000) ao Portal de
    Relatorios na AWS, via tunel reverso FRP. Roda como tarefa
    de inicializacao do Windows (sobe sozinho e reinicia).

    USO (PowerShell como Administrador):
      .\INSTALAR_TUNEL.ps1 -Cnpj "00000000000000" -RemotePort 16001 -Token "TOKEN_DO_BROKER"

    Parametros:
      -Cnpj        CNPJ da loja (so numeros) - identifica o tunel
      -RemotePort  Porta exclusiva desta loja no broker (cada loja uma)
      -Token       Token do broker FRP (mesmo do servidor, secrets.env)
      -ServerAddr  IP do broker (padrao: 98.94.223.97)
      -LocalPort   Porta da API local (padrao: 5000)
    ============================================================ #>

param(
    [Parameter(Mandatory=$true)][string]$Cnpj,
    [Parameter(Mandatory=$true)][int]$RemotePort,
    [Parameter(Mandatory=$true)][string]$Token,
    [string]$ServerAddr = "98.94.223.97",
    [int]$LocalPort = 5000
)

$ErrorActionPreference = "Stop"
$base = "C:\InfoSistemas\tunel"
$cnpjLimpo = ($Cnpj -replace '\D','')

Write-Host ">> [1/5] Preparando pasta $base ..."
New-Item -ItemType Directory -Force -Path $base | Out-Null

Write-Host ">> [2/5] Descobrindo e baixando o frpc (cliente FRP)..."
$rel = Invoke-RestMethod -Uri "https://api.github.com/repos/fatedier/frp/releases/latest" -Headers @{ "User-Agent" = "InfoSistemas" }
$ver = $rel.tag_name.TrimStart("v")
$asset = $rel.assets | Where-Object { $_.name -eq "frp_${ver}_windows_amd64.zip" } | Select-Object -First 1
if (-not $asset) { throw "Nao encontrei o pacote frp windows_amd64 na release $ver" }
$zip = Join-Path $base "frp.zip"
Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zip -UseBasicParsing
Expand-Archive -Path $zip -DestinationPath $base -Force
$frpcSrc = Get-ChildItem -Path $base -Recurse -Filter "frpc.exe" | Select-Object -First 1
Copy-Item $frpcSrc.FullName (Join-Path $base "frpc.exe") -Force
Remove-Item $zip -Force

Write-Host ">> [3/5] Gravando configuracao frpc.toml ..."
$conf = @"
serverAddr = "$ServerAddr"
serverPort = 7000
auth.method = "token"
auth.token = "$Token"

[[proxies]]
name = "loja-$cnpjLimpo-api"
type = "tcp"
localIP = "127.0.0.1"
localPort = $LocalPort
remotePort = $RemotePort
"@
Set-Content -Path (Join-Path $base "frpc.toml") -Value $conf -Encoding UTF8

Write-Host ">> [4/5] Registrando tarefa de inicializacao (InfoSistemas-Tunel)..."
$exe = Join-Path $base "frpc.exe"
$cfg = Join-Path $base "frpc.toml"
$action  = New-ScheduledTaskAction -Execute $exe -Argument "-c `"$cfg`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$princ   = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$set     = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Unregister-ScheduledTask -TaskName "InfoSistemas-Tunel" -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName "InfoSistemas-Tunel" -Action $action -Trigger $trigger -Principal $princ -Settings $set | Out-Null

Write-Host ">> [5/5] Iniciando o tunel agora..."
Start-ScheduledTask -TaskName "InfoSistemas-Tunel"
Start-Sleep -Seconds 3
Write-Host "------------------------------------------------------------"
Write-Host "OK! Tunel da loja CNPJ $cnpjLimpo ativo."
Write-Host "  Broker:      $ServerAddr:7000"
Write-Host "  API local:   127.0.0.1:$LocalPort  ->  porta remota $RemotePort"
Write-Host "  No portal, cadastre esta loja com 'Porta tunel' = $RemotePort"
Write-Host "------------------------------------------------------------"
