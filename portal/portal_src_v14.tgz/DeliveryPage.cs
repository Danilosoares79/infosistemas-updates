namespace InfoSistemas.Portal;

/// <summary>
/// Página mobile do DELIVERY ONLINE, servida em /delivery/{loja}.
/// Fluxo: cadastro do cliente → cardápio → carrinho → forma de pagamento → enviar.
/// O pedido cai na fila do Frente de Caixa (SITUACAO='AG') para aprovação.
/// Mesmo cardápio do autoatendimento. Chama o proxy /entrega/{loja}/...
/// </summary>
public static class DeliveryPage
{
    public static string Html(string loja)
    {
        var lojaSan = new string((loja ?? "").Where(char.IsLetterOrDigit).ToArray());
        return TEMPLATE.Replace("__LOJA__", lojaSan);
    }

    private const string TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Delivery</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#f4f6fb;color:#1e293b;padding-bottom:96px}
#marca{position:fixed;inset:0;background-repeat:no-repeat;background-position:center 46%;background-size:68%;opacity:.06;z-index:0;pointer-events:none;display:none}
#app{position:relative;z-index:1;max-width:720px;margin:0 auto}
.top{background:#1e40af;color:#fff;padding:14px 16px;text-align:center;position:sticky;top:0;z-index:30;box-shadow:0 2px 8px rgba(0,0,0,.15)}
.top .logo{max-height:54px;max-width:70%;margin:0 auto 6px;display:none;border-radius:8px}
.top h1{font-size:20px;font-weight:700}
.top .sub{font-size:12px;opacity:.9;margin-top:2px}
.badge{display:inline-block;margin-top:6px;font-size:12px;font-weight:700;background:#16a34a;padding:3px 10px;border-radius:20px}
.badge.fechado{background:#dc2626}
.sec{padding:14px 16px}
.card{background:#fff;border-radius:14px;box-shadow:0 1px 5px rgba(0,0,0,.06);padding:16px;margin-bottom:14px}
h2{font-size:16px;margin-bottom:10px;color:#1e293b}
label{display:block;font-size:13px;font-weight:600;margin:10px 0 4px;color:#475569}
input,select,textarea{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:10px;font-size:15px;background:#fff;font-family:inherit}
input:focus,select:focus,textarea:focus{outline:none;border-color:#1e40af}
.row{display:flex;gap:10px}
.row>div{flex:1}
.btn{display:block;width:100%;padding:15px;border:none;border-radius:12px;font-size:16px;font-weight:700;cursor:pointer;background:#1e40af;color:#fff;margin-top:16px}
.btn:active{opacity:.85}
.btn.sec2{background:#e2e8f0;color:#1e293b}
.grp{font-size:15px;font-weight:800;color:#1e40af;margin:18px 0 8px;padding:0 16px}
.prod{display:flex;gap:12px;align-items:center;background:#fff;border-radius:14px;box-shadow:0 1px 5px rgba(0,0,0,.06);padding:12px;margin:0 16px 10px}
.pfoto{width:92px;height:92px;border-radius:10px;object-fit:cover;flex-shrink:0;background:#eef2f7;cursor:pointer}
.pinfo{flex:1;min-width:0}
.pnome{font-weight:700;font-size:15px}
.pdesc{font-size:12px;color:#64748b;margin-top:2px}
.ppreco{font-weight:800;color:#16a34a;margin-top:6px}
.padd{background:#1e40af;color:#fff;border:none;border-radius:10px;width:42px;height:42px;font-size:24px;font-weight:700;cursor:pointer;flex-shrink:0}
.bar{position:fixed;left:0;right:0;bottom:0;z-index:40;background:#fff;box-shadow:0 -2px 12px rgba(0,0,0,.12);padding:10px 14px;display:none}
.bar .inner{max-width:720px;margin:0 auto;display:flex;gap:10px}
.bcart{flex:1;background:#16a34a;color:#fff;border:none;border-radius:12px;padding:14px;font-size:16px;font-weight:800;cursor:pointer;display:flex;justify-content:space-between;align-items:center}
.sheet{position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.45);display:none;align-items:flex-end}
.sheet .panel{background:#fff;width:100%;max-width:720px;margin:0 auto;border-radius:18px 18px 0 0;max-height:88vh;overflow-y:auto;padding:18px}
.sheet h2{display:flex;justify-content:space-between;align-items:center}
.sheet .x{background:none;border:none;font-size:26px;cursor:pointer;color:#64748b;line-height:1}
.ci{display:flex;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid #eef2f7}
.ci .n{flex:1}
.ci .nome{font-weight:600;font-size:14px}
.ci .pr{font-size:12px;color:#64748b}
.qbtn{background:#e2e8f0;border:none;width:34px;height:34px;border-radius:8px;font-size:20px;font-weight:700;cursor:pointer}
.qn{min-width:26px;text-align:center;font-weight:700}
.tot{display:flex;justify-content:space-between;font-size:15px;margin:6px 0}
.tot.g{font-size:19px;font-weight:800;border-top:2px solid #1e293b;padding-top:8px;margin-top:8px}
.pg{display:flex;gap:8px;margin-top:8px}
.pg button{flex:1;padding:12px;border:2px solid #cbd5e1;background:#fff;border-radius:10px;font-weight:700;cursor:pointer;font-size:14px}
.pg button.on{border-color:#1e40af;background:#eef2ff;color:#1e40af}
.msg{padding:30px 16px;text-align:center;color:#64748b}
.fechado-box{margin:30px 16px;background:#fff;border-radius:14px;padding:30px 20px;text-align:center;box-shadow:0 1px 5px rgba(0,0,0,.06)}
.fechado-box .ic{font-size:48px}
.ok-box{margin:40px 16px;background:#fff;border-radius:16px;padding:36px 24px;text-align:center;box-shadow:0 1px 5px rgba(0,0,0,.06)}
.ok-box .ic{font-size:64px}
.ok-box h2{font-size:22px;color:#16a34a;margin:14px 0 6px}
#lightbox{position:fixed;inset:0;z-index:80;background:rgba(0,0,0,.9);display:none;align-items:center;justify-content:center;padding:16px}
#lightbox img{width:92vw;max-width:560px;max-height:86vh;object-fit:contain;border-radius:10px}
.hint{font-size:12px;color:#94a3b8;margin-top:4px}
</style>
</head>
<body>
<div id="marca"></div>
<div id="app">
  <div class="top">
    <img class="logo" id="logo" src="" alt="">
    <h1 id="estab">Carregando…</h1>
    <div class="sub">Delivery / Entrega</div>
    <div class="badge" id="badge" style="display:none"></div>
  </div>
  <div id="conteudo"><div class="msg">Carregando…</div></div>
</div>

<!-- Barra do carrinho -->
<div class="bar" id="bar"><div class="inner">
  <button class="bcart" id="bcart" onclick="abrirCarrinho()"><span>🛒 Ver carrinho</span><span id="bcartv">R$ 0,00</span></button>
</div></div>

<!-- Bottom sheet (carrinho / pagamento) -->
<div class="sheet" id="sheet"><div class="panel" id="sheetPanel"></div></div>

<!-- Lightbox da foto -->
<div id="lightbox" onclick="this.style.display='none'"><img id="lightboxImg" src="" alt=""></div>

<script>
var LOJA="__LOJA__";
var DADOS=null, CART=[], CLIENTE=null, FORMA="DINHEIRO";

function brl(v){try{return (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}catch(e){return 'R$ '+(v||0).toFixed(2);}}
function esc(s){return (s==null?'':(''+s)).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function img64(b){if(!b)return '';return (''+b).indexOf('data:')===0?b:('data:image/jpeg;base64,'+b);}

function carregar(){
  fetch('/entrega/'+LOJA+'/cardapio',{cache:'no-store'})
   .then(function(r){return r.json();})
   .then(function(j){
      if(!j||!j.ok||!j.dados){throw new Error((j&&j.mensagem)||'falha');}
      DADOS=j.dados; aplicarTema();
      if(DADOS.aberto===false){ telaFechado(); }
      else { telaCadastro(); }
   })
   .catch(function(){document.getElementById('conteudo').innerHTML='<div class="msg">Não foi possível carregar o cardápio. Tente novamente em instantes.</div>';});
}

function aplicarTema(){
  var t=DADOS.tema||{};
  document.getElementById('estab').textContent=DADOS.nomeEstabelecimento||t.nomeEstabelecimento||'Delivery';
  var b=document.getElementById('badge');
  if(DADOS.aberto===false){b.textContent='🔴 Fechado agora';b.className='badge fechado';}
  else{b.textContent='🟢 Aberto • Recebendo pedidos';b.className='badge';}
  b.style.display='inline-block';
  if(t.logoBase64){var ls=img64(t.logoBase64);var lg=document.getElementById('logo');lg.src=ls;lg.style.display='block';var mc=document.getElementById('marca');mc.style.backgroundImage='url('+ls+')';mc.style.display='block';}
}

function telaFechado(){
  document.getElementById('bar').style.display='none';
  document.getElementById('conteudo').innerHTML=
    '<div class="fechado-box"><div class="ic">😴</div><h2>Estamos fechados no momento</h2>'+
    '<p style="color:#64748b;margin-top:8px">O estabelecimento não está recebendo pedidos online agora. Volte mais tarde!</p></div>';
}

// ── 1) CADASTRO DO CLIENTE ───────────────────────────────────────────────
function telaCadastro(){
  document.getElementById('bar').style.display='none';
  var bairros=(DADOS.bairros||[]);
  var opts='<option value="">Selecione seu bairro…</option>';
  bairros.forEach(function(b){opts+='<option value="'+b.codigo+'" data-taxa="'+(b.taxa||0)+'">'+esc(b.nome)+(b.taxa>0?(' (+'+brl(b.taxa)+')'):'')+'</option>';});
  var c=CLIENTE||{};
  document.getElementById('conteudo').innerHTML=
   '<div class="sec"><div class="card">'+
   '<h2>📝 Seus dados para entrega</h2>'+
   '<label>Nome *</label><input id="f_nome" value="'+esc(c.nome||'')+'" placeholder="Seu nome">'+
   '<label>Telefone / WhatsApp *</label><input id="f_tel" type="tel" inputmode="numeric" value="'+esc(c.telefone||'')+'" placeholder="(00) 00000-0000">'+
   '<label>Endereço (rua) *</label><input id="f_end" value="'+esc(c.endereco||'')+'" placeholder="Rua / Avenida">'+
   '<div class="row"><div><label>Número</label><input id="f_num" value="'+esc(c.numero||'')+'" placeholder="123"></div>'+
   '<div><label>Complemento</label><input id="f_comp" value="'+esc(c.complemento||'')+'" placeholder="Apto / bloco"></div></div>'+
   (bairros.length?('<label>Bairro *</label><select id="f_bairro">'+opts+'</select>'):
     '<label>Bairro</label><input id="f_bairro_txt" value="'+esc(c.bairroTxt||'')+'" placeholder="Seu bairro">')+
   '<label>Ponto de referência (opcional)</label><input id="f_obs" value="'+esc(c.observacoes||'')+'" placeholder="Ex: portão azul">'+
   '<button class="btn" onclick="salvarCadastro()">Ver cardápio →</button>'+
   '<div class="hint">O pagamento é na entrega. A taxa depende do bairro.</div>'+
   '</div></div>';
  var sel=document.getElementById('f_bairro');
  if(sel&&c.fkBairro){sel.value=c.fkBairro;}
}

function salvarCadastro(){
  var g=function(id){var e=document.getElementById(id);return e?e.value.trim():'';};
  var nome=g('f_nome'),tel=g('f_tel'),end=g('f_end');
  if(!nome){alert('Informe seu nome.');return;}
  if(!tel){alert('Informe seu telefone.');return;}
  if(!end){alert('Informe o endereço de entrega.');return;}
  var fkBairro=null,taxa=0,bairroTxt='';
  var sel=document.getElementById('f_bairro');
  if(sel){
    if(!sel.value){alert('Selecione seu bairro.');return;}
    fkBairro=parseInt(sel.value);
    var op=sel.options[sel.selectedIndex];
    taxa=parseFloat(op.getAttribute('data-taxa')||'0')||0;
    bairroTxt=op.textContent;
  } else { bairroTxt=g('f_bairro_txt'); }
  CLIENTE={nome:nome,telefone:tel,endereco:end,numero:g('f_num'),complemento:g('f_comp'),
           fkBairro:fkBairro,taxa:taxa,bairroTxt:bairroTxt,observacoes:g('f_obs')};
  telaCardapio();
}

// ── 2) CARDÁPIO ───────────────────────────────────────────────────────────
function telaCardapio(){
  var prods=(DADOS.produtos||[]).filter(function(p){return p.disponivel!==false;});
  var grupos=DADOS.grupos||[];
  var t=DADOS.tema||{};
  var fotos=(t.mostrarFotos!==false);
  var html='<div style="padding:12px 16px 0"><button class="btn sec2" onclick="telaCadastro()" style="margin:0">✏️ Alterar meus dados</button></div>';
  function cardProd(p){
    var foto=(fotos&&p.fotoBase64)?('<img class="pfoto" src="'+img64(p.fotoBase64)+'" onclick="zoom(this.src)">'):'';
    // [v7.6.137] Produto em PROMOÇÃO: mostra o preço antigo riscado + o promocional + selo.
    var precoHtml = p.temPromocao
      ? '<div class="ppreco"><span style="text-decoration:line-through;color:#9ca3af;font-weight:400;font-size:13px">'+brl(p.precoOriginal)+'</span> '+
        '<span style="color:#dc2626;font-weight:800">'+brl(p.preco)+'</span> '+
        '<span style="background:#dc2626;color:#fff;border-radius:6px;padding:1px 6px;font-size:10px;font-weight:800;vertical-align:middle">PROMO</span></div>'
      : '<div class="ppreco">'+brl(p.preco)+'</div>';
    return '<div class="prod">'+foto+'<div class="pinfo"><div class="pnome">'+esc(p.descricao)+'</div>'+
      (p.descricao2?('<div class="pdesc">'+esc(p.descricao2)+'</div>'):'')+
      precoHtml+'</div>'+
      '<button class="padd" onclick="add('+p.codigo+')">+</button></div>';
  }
  if(grupos.length){
    grupos.forEach(function(g){
      var lista=prods.filter(function(p){return p.grupo===g.codigo;});
      if(!lista.length)return;
      html+='<div class="grp">'+esc((g.emoji?g.emoji+' ':'')+g.descricao)+'</div>';
      lista.forEach(function(p){html+=cardProd(p);});
    });
    var semg=prods.filter(function(p){return !grupos.some(function(g){return g.codigo===p.grupo;});});
    if(semg.length){html+='<div class="grp">Outros</div>';semg.forEach(function(p){html+=cardProd(p);});}
  } else {
    prods.forEach(function(p){html+=cardProd(p);});
  }
  if(!prods.length)html='<div class="msg">Nenhum produto disponível no momento.</div>';
  document.getElementById('conteudo').innerHTML=html;
  atualizarBarra();
}

function prod(cod){return (DADOS.produtos||[]).find(function(p){return p.codigo===cod;});}
function add(cod){
  var p=prod(cod);
  if(p&&((p.adicionais&&p.adicionais.length)||(p.grupos&&p.grupos.length))){abrirAdicionais(p);return;}
  var it=CART.find(function(i){return i.cod===cod && !(i.adic&&i.adic.length);});
  if(it){it.qtd++;}else{CART.push({cod:cod,nome:p.descricao,preco:p.preco,qtd:1,adic:[]});}
  atualizarBarra();
  var b=document.getElementById('bcart');b.style.transform='scale(1.04)';setTimeout(function(){b.style.transform='';},120);
}
// [7.6.111] modal de complementos/adicionais por GRUPO (mín/máx, obrigatório, repetir); fallback flat
function abrirAdicionais(p){
  var h='<h2>Monte seu item <button class="x" onclick="fechar()">×</button></h2>';
  h+='<div style="font-weight:600;margin-bottom:8px">'+esc(p.descricao)+'</div>';
  if(p.grupos&&p.grupos.length){
    p.grupos.forEach(function(g,gi){
      var obr=g.obrigatorio||g.min>=1;
      var reg=[obr?('obrigatório — mín '+Math.max(1,g.min)):'opcional'];
      if(g.max>0)reg.push('até '+g.max); if(g.repetir)reg.push('pode repetir');
      var cor=g.tipo==='ADICIONAL'?'#d52b1e':'#0d9488'; var single=g.max===1;
      h+='<div style="margin:10px 0 4px"><div style="font-weight:700;color:'+cor+'">'+esc(g.nome)+'</div>'+
         '<div style="font-size:11px;color:#94a3b8;margin-bottom:4px">'+reg.join(' • ')+'</div>';
      g.itens.forEach(function(a,ii){
        var inp=single
          ?'<input type="radio" name="grp_'+gi+'" class="adg" data-gi="'+gi+'" data-ii="'+ii+'">'
          :'<input type="checkbox" class="adg" data-gi="'+gi+'" data-ii="'+ii+'">';
        var pr=a.preco>0?'<span class="pr">'+brl(a.preco)+'</span>':'';
        var qty=g.repetir?'<input type="number" class="adgq" data-gi="'+gi+'" data-ii="'+ii+'" value="1" min="1" style="width:52px;margin-left:8px">':'';
        h+='<div class="ci"><label style="flex:1;display:flex;align-items:center;gap:8px">'+inp+'<span>'+esc(a.descricao)+'</span></label>'+pr+qty+'</div>';
      });
      h+='</div>';
    });
  } else {
    p.adicionais.forEach(function(a,i){
      h+='<div class="ci"><label style="flex:1;display:flex;align-items:center;gap:8px">'+
         '<input type="checkbox" id="adc_'+i+'"><span>'+esc(a.descricao)+'</span></label>'+
         '<span class="pr">'+brl(a.preco)+'</span>'+
         '<input type="number" id="adq_'+i+'" value="1" min="1" style="width:52px;margin-left:8px">'+
         '</div>';
    });
  }
  h+='<button class="btn" onclick="addComAdic('+p.codigo+')">Adicionar ao pedido</button>';
  document.getElementById('sheetPanel').innerHTML=h;
  document.getElementById('sheet').style.display='flex';
}
function addComAdic(cod){
  var p=prod(cod);var adic=[];
  if(p.grupos&&p.grupos.length){
    for(var gi=0;gi<p.grupos.length;gi++){
      var g=p.grupos[gi];var n=0;
      for(var ii=0;ii<g.itens.length;ii++){
        var c=document.querySelector('.adg[data-gi="'+gi+'"][data-ii="'+ii+'"]');
        if(c&&c.checked){var q=document.querySelector('.adgq[data-gi="'+gi+'"][data-ii="'+ii+'"]');
          var qq=Math.max(1,parseInt((q&&q.value)||'1')||1); n+=qq;
          var a=g.itens[ii]; adic.push({fkAdicional:a.fkAdicional,quantidade:qq,nome:a.descricao,preco:a.preco});}
      }
      var min=(g.obrigatorio||g.min>=1)?Math.max(1,g.min):g.min;
      if(n<min){alert('No grupo "'+g.nome+'" escolha ao menos '+min+'.');return;}
      if(g.max>0&&n>g.max){alert('No grupo "'+g.nome+'" o máximo é '+g.max+'.');return;}
    }
  } else {
    (p.adicionais||[]).forEach(function(a,i){var c=document.getElementById('adc_'+i);
      if(c&&c.checked){var q=document.getElementById('adq_'+i);var qq=Math.max(1,parseInt((q&&q.value)||'1')||1);
        adic.push({fkAdicional:a.fkAdicional,quantidade:qq,nome:a.descricao,preco:a.preco});}});
  }
  CART.push({cod:cod,nome:p.descricao,preco:p.preco,qtd:1,adic:adic});
  fechar();atualizarBarra();
  var b=document.getElementById('bcart');if(b){b.style.transform='scale(1.04)';setTimeout(function(){b.style.transform='';},120);}
}
function chQtd(cod,d){var it=CART.find(function(i){return i.cod===cod;});if(!it)return;it.qtd+=d;if(it.qtd<=0){CART=CART.filter(function(i){return i.cod!==cod;});}atualizarBarra();if(document.getElementById('sheet').style.display==='flex')abrirCarrinho();}
function totalItens(){return CART.reduce(function(s,i){var t=i.preco*i.qtd;(i.adic||[]).forEach(function(a){t+=a.preco*a.quantidade;});return s+t;},0);}
function taxaEntrega(){return (CLIENTE&&CLIENTE.taxa)?CLIENTE.taxa:0;}
function atualizarBarra(){
  var bar=document.getElementById('bar');var n=CART.reduce(function(s,i){return s+i.qtd;},0);
  if(n>0){bar.style.display='block';document.getElementById('bcartv')
    .textContent=n+' item(s) • '+brl(totalItens());}
  else{bar.style.display='none';}
}

// ── 3) CARRINHO + PAGAMENTO ───────────────────────────────────────────────
function abrirCarrinho(){
  if(!CART.length){return;}
  var h='<h2>🛒 Seu pedido <button class="x" onclick="fechar()">×</button></h2>';
  CART.forEach(function(i){
    h+='<div class="ci"><div class="n"><div class="nome">'+esc(i.nome)+'</div><div class="pr">'+brl(i.preco)+' un</div></div>'+
       '<button class="qbtn" onclick="chQtd('+i.cod+',-1)">−</button><span class="qn">'+i.qtd+'</span>'+
       '<button class="qbtn" onclick="chQtd('+i.cod+',1)">+</button></div>';
    (i.adic||[]).forEach(function(a){
      h+='<div class="ci" style="padding-left:16px;font-size:13px;color:#475569">'+
         '<div class="n"><div class="nome">+ '+esc(a.nome)+'</div></div>'+
         '<span class="pr">'+a.quantidade+'x '+brl(a.preco)+'</span></div>';
    });
  });
  var ti=totalItens(),tx=taxaEntrega();
  h+='<div class="tot"><span>Itens</span><span>'+brl(ti)+'</span></div>';
  h+='<div class="tot"><span>Taxa de entrega'+(CLIENTE&&CLIENTE.bairroTxt?(' • '+esc(CLIENTE.bairroTxt)):'')+'</span><span>'+brl(tx)+'</span></div>';
  h+='<div class="tot g"><span>Total</span><span>'+brl(ti+tx)+'</span></div>';
  h+='<label style="margin-top:14px">Forma de pagamento (na entrega)</label>';
  h+='<div class="pg">'+
     '<button id="pg_DINHEIRO" onclick="setForma(\'DINHEIRO\')">💵 Dinheiro</button>'+
     '<button id="pg_CARTAO" onclick="setForma(\'CARTAO\')">💳 Cartão</button>'+
     '<button id="pg_PIX" onclick="setForma(\'PIX\')">📱 Pix</button></div>';
  h+='<div id="trocoBox" style="display:none"><label>Troco para quanto? (opcional)</label>'+
     '<input id="f_troco" type="number" inputmode="decimal" placeholder="Ex: 50,00"></div>';
  h+='<button class="btn" id="btnEnviar" onclick="enviar()">Enviar pedido • '+brl(ti+tx)+'</button>';
  document.getElementById('sheetPanel').innerHTML=h;
  document.getElementById('sheet').style.display='flex';
  setForma(FORMA);
}
function setForma(f){
  FORMA=f;
  ['DINHEIRO','CARTAO','PIX'].forEach(function(k){var b=document.getElementById('pg_'+k);if(b)b.className=(k===f?'on':'');});
  var tb=document.getElementById('trocoBox');if(tb)tb.style.display=(f==='DINHEIRO'?'block':'none');
}
function fechar(){document.getElementById('sheet').style.display='none';}

function enviar(){
  if(!CART.length){alert('Carrinho vazio.');return;}
  if(!CLIENTE){telaCadastro();return;}
  var btn=document.getElementById('btnEnviar');if(btn){btn.disabled=true;btn.textContent='Enviando…';}
  var troco=0;var ft=document.getElementById('f_troco');if(ft&&FORMA==='DINHEIRO'){troco=parseFloat((ft.value||'0').replace(',','.'))||0;}
  var body={
    nome:CLIENTE.nome, telefone:CLIENTE.telefone, documento:'',
    cep:'', endereco:CLIENTE.endereco, numero:CLIENTE.numero, complemento:CLIENTE.complemento,
    fkBairro:CLIENTE.fkBairro, formaPgto:FORMA, trocoPara:troco,
    observacoes:CLIENTE.observacoes,
    itens:CART.map(function(i){return {fkProduto:i.cod, quantidade:i.qtd, obs:'', adicionais:(i.adic||[]).map(function(a){return {fkAdicional:a.fkAdicional, quantidade:a.quantidade};})};})
  };
  fetch('/entrega/'+LOJA+'/pedido',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
   .then(function(r){return r.json();})
   .then(function(j){
      if(j&&j.ok){ telaSucesso(j.dados&&j.dados.codigo); }
      else { alert((j&&j.mensagem)||'Não foi possível enviar o pedido.'); if(btn){btn.disabled=false;abrirCarrinho();} }
   })
   .catch(function(){alert('Falha de conexão. Tente novamente.');if(btn){btn.disabled=false;abrirCarrinho();}});
}

function telaSucesso(cod){
  fechar();CART=[];atualizarBarra();
  document.getElementById('bar').style.display='none';
  document.getElementById('conteudo').innerHTML=
    '<div class="ok-box"><div class="ic">✅</div><h2>Pedido enviado!</h2>'+
    (cod?('<p style="color:#64748b">Pedido nº <b>#'+cod+'</b></p>'):'')+
    '<p style="color:#64748b;margin-top:8px">Aguarde a confirmação do estabelecimento. Em breve seu pedido estará a caminho!</p>'+
    '<button class="btn" onclick="location.reload()" style="margin-top:20px">Fazer outro pedido</button></div>';
}

function zoom(src){document.getElementById('lightboxImg').src=src;document.getElementById('lightbox').style.display='flex';}

carregar();
</script>
</body>
</html>
""";
}
