#!/usr/bin/env bash
# ============================================================
# Deploy do InfoSistemas - Portal de Relatorios (versao remota)
# Uso (na janela SSH do servidor do portal):
#     export ADMIN_SENHA='SuaSenhaForte'
#     curl -fsSL https://github.com/Danilosoares79/infosistemas-updates/releases/download/portal/deploy_portal_remote.sh | bash
# ============================================================
set -euo pipefail

SRC_URL="https://github.com/Danilosoares79/infosistemas-updates/releases/download/portal/portal_src.tgz"
APPDIR=/opt/infosistemas/portal-app
SECRETS=/opt/infosistemas/portal/secrets.env
ENVFILE=/opt/infosistemas/portal/.env

if [ -z "${ADMIN_SENHA:-}" ]; then
  echo "ERRO: defina a senha do admin antes. Ex:  export ADMIN_SENHA='SuaSenha'"; exit 1
fi

echo ">> [1/6] Descobrindo senha do MySQL e a rede Docker..."
MYSQL_PASSWORD=""
for f in "$SECRETS" "$ENVFILE"; do
  if [ -f "$f" ]; then
    v=$(sudo grep -E '^MYSQL_PASSWORD=' "$f" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"' || true)
    [ -n "$v" ] && MYSQL_PASSWORD="$v"
  fi
done
if [ -z "$MYSQL_PASSWORD" ]; then
  echo "ERRO: nao encontrei MYSQL_PASSWORD em $SECRETS nem $ENVFILE."; exit 1
fi

DB_NETWORK=$(sudo docker inspect portal-mysql-1 -f '{{range $k,$v := .NetworkSettings.Networks}}{{println $k}}{{end}}' 2>/dev/null | head -1)
if [ -z "$DB_NETWORK" ]; then
  echo "ERRO: nao achei a rede do container portal-mysql-1."; exit 1
fi
echo "   Rede do MySQL: $DB_NETWORK"

echo ">> [2/6] Baixando e extraindo o codigo do portal em $APPDIR ..."
sudo mkdir -p "$APPDIR"
curl -fsSL "$SRC_URL" -o /tmp/portal_src.tgz
sudo tar xz -C "$APPDIR" -f /tmp/portal_src.tgz
rm -f /tmp/portal_src.tgz

echo ">> [3/6] Gravando .env do compose (protegido)..."
sudo tee "$APPDIR/.env" >/dev/null <<EOF
MYSQL_PASSWORD=$MYSQL_PASSWORD
ADMIN_SENHA=$ADMIN_SENHA
PORTAL_ADMIN_LOGIN=admin
DB_NETWORK=$DB_NETWORK
EOF
sudo chmod 600 "$APPDIR/.env"

echo ">> [4/6] Build e subida do container (pode levar 1-2 min)..."
cd "$APPDIR"
sudo docker compose up -d --build

echo ">> [5/6] Configurando o Caddy (reverse proxy)..."
sudo tee /etc/caddy/Caddyfile >/dev/null <<'EOF'
portal.infosistemas.net.br {
    encode gzip
    reverse_proxy 127.0.0.1:8080
}
EOF
sudo systemctl reload caddy

echo ">> [6/6] Aguardando o portal responder..."
sleep 8
sudo docker compose ps
echo "------------------------------------------------------------"
echo "OK! Acesse: https://portal.infosistemas.net.br"
echo "Admin: usuario 'admin' + a senha definida em ADMIN_SENHA"
echo "------------------------------------------------------------"
