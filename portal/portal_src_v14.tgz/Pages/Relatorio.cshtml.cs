using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[Authorize]
public class RelatorioModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public RelatorioModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public string Codigo { get; private set; } = "";
    public string Nome { get; private set; } = "";
    public string Categoria { get; private set; } = "";
    public string Loja { get; private set; } = "";
    public bool TemFiltroData { get; private set; }
    public string De { get; set; } = "";
    public string Ate { get; set; } = "";
    public List<string> Colunas { get; private set; } = new();
    public List<Dictionary<string, string>> Linhas { get; private set; } = new();
    public string? Aviso { get; private set; }

    // campo -> formato (ex.: "N2" = monetario/decimal). Usado para exibir R$ com 2 casas.
    private readonly Dictionary<string, string> _formatos = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _direita = new(StringComparer.OrdinalIgnoreCase);

    // NumberFormatInfo MANUAL (vírgula decimal, ponto de milhar) — NAO usar
    // CultureInfo.GetCultureInfo("pt-BR"): o container roda com
    // InvariantGlobalization=true e a busca de cultura lança excecao (HTTP 500).
    private static readonly System.Globalization.NumberFormatInfo BrNum = new()
    {
        NumberDecimalSeparator = ",",
        NumberGroupSeparator = ".",
    };

    public bool AlinhaDireita(string col) => _direita.Contains(col);

    /// <summary>coluna -> total somado (já formatado), para o rodapé de totais.</summary>
    public Dictionary<string, string> Totais { get; } = new(StringComparer.OrdinalIgnoreCase);

    private static bool EhMoeda(string fmt) =>
        !string.IsNullOrEmpty(fmt) && (fmt.StartsWith("N", StringComparison.OrdinalIgnoreCase)
                                    || fmt.StartsWith("C", StringComparison.OrdinalIgnoreCase)
                                    || fmt.StartsWith("F", StringComparison.OrdinalIgnoreCase));

    private static string FmtNum(decimal d, string fmt)
    {
        int casas = 2;
        if (fmt.Length > 1 && int.TryParse(fmt.Substring(1), out var n)) casas = n;
        return d.ToString("N" + casas, BrNum);
    }

    /// <summary>Formata o valor da célula: colunas N2/C2 viram número com 2 casas (pt-BR). Demais ficam como vieram.</summary>
    public string FormatCell(string col, string valor)
    {
        if (string.IsNullOrEmpty(valor)) return "";
        try
        {
            var fmt = _formatos.TryGetValue(col, out var f) ? f : "";
            // valor vem do JSON como invariante (ex.: "10" ou "10.5")
            if (EhMoeda(fmt) && decimal.TryParse(valor, System.Globalization.NumberStyles.Any,
                                                 System.Globalization.CultureInfo.InvariantCulture, out var d))
                return FmtNum(d, fmt);
        }
        catch { /* nunca derruba o relatorio por formatacao */ }
        return valor;
    }

    /// <summary>Soma as colunas monetárias (replica o rodapé de totais do sistema desktop).</summary>
    public bool TemTotais => Totais.Count > 0;
    private void CalcularTotais()
    {
        try
        {
            foreach (var col in Colunas)
            {
                var fmt = _formatos.TryGetValue(col, out var f) ? f : "";
                if (!EhMoeda(fmt)) continue;
                decimal soma = 0; bool tem = false;
                foreach (var ln in Linhas)
                    if (ln.TryGetValue(col, out var v) && decimal.TryParse(v,
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture, out var d))
                    { soma += d; tem = true; }
                if (tem) Totais[col] = FmtNum(soma, fmt);
            }
        }
        catch { /* rodapé é opcional */ }
    }

    public async Task<IActionResult> OnGetAsync(string codigo, string? de, string? ate)
    {
        Codigo = codigo;
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        // [v7] Permissão por relatório (vazio = acesso total)
        if (!Permissao.TemRelatorio(User, codigo))
        {
            Aviso = "Seu usuário não tem acesso a este relatório.";
            return Page();
        }

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null || cliente.TunnelPort <= 0)
        {
            Aviso = "Canal de dados não configurado para esta loja.";
            return Page();
        }
        var porta = cliente.TunnelPort;

        // Catálogo → metadados do relatório (nome + parâmetros de data)
        var cat = await _api.CatalogoAsync(porta);
        var def = cat.FirstOrDefault(r => r.Id == codigo);
        if (def == null)
        {
            Aviso = cat.Count == 0
                ? "A loja está offline no momento. Tente novamente quando estiver conectada."
                : "Relatório não encontrado.";
            return Page();
        }
        Nome = def.Nome;
        Categoria = def.Categoria;

        foreach (var col in def.Colunas)
        {
            if (!string.IsNullOrEmpty(col.Formato)) _formatos[col.Campo] = col.Formato;
            if (col.Direita) _direita.Add(col.Campo);
        }

        // Empresa (código) da loja
        var emp = await _api.EmpresaAsync(porta);
        var empresa = emp?.Codigo ?? 1;

        // Filtros de período (se o relatório tiver parâmetros de data)
        var pDe = def.Parametros.FirstOrDefault(p => p.Tipo == "DataDe");
        var pAte = def.Parametros.FirstOrDefault(p => p.Tipo == "DataAte");
        TemFiltroData = pDe != null || pAte != null;

        De = !string.IsNullOrEmpty(de) ? de : DateTime.Today.AddDays(-30).ToString("yyyy-MM-dd");
        Ate = !string.IsNullOrEmpty(ate) ? ate : DateTime.Today.ToString("yyyy-MM-dd");

        var filtros = new Dictionary<string, string>();
        if (pDe != null) filtros[pDe.Nome] = De;
        if (pAte != null) filtros[pAte.Nome] = Ate;

        var res = await _api.ExecutarAsync(porta, codigo, empresa, filtros);
        if (res == null)
        {
            Aviso = "Não foi possível obter os dados (loja offline ou erro na consulta).";
            return Page();
        }
        Colunas = res.Colunas;
        Linhas = res.Linhas;
        CalcularTotais();
        return Page();
    }
}
