using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>
/// [v7.6.174] XML Saída remoto — o cliente (ou contador) baixa pelo portal um
/// ZIP com TODOS os XMLs de NFC-e do período (todos os caixas da loja) + os
/// relatórios de Notas (autorizadas/canceladas/pendentes/inutilizadas) e de
/// CFOP com totalizadores — igual à tela Vendas → Exportar XML Saída do
/// Retaguarda, sem precisar estar no local.
/// </summary>
[Authorize]
public class XmlSaidaModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public XmlSaidaModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public string Loja { get; private set; } = "";
    public string De { get; set; } = "";
    public string Ate { get; set; } = "";
    public XmlSaidaResumo? Resumo { get; private set; }
    public string? Aviso { get; private set; }

    private async Task<(int Porta, int Empresa)?> ResolverLojaAsync()
    {
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";
        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null || cliente.TunnelPort <= 0) return null;
        var emp = await _api.EmpresaAsync(cliente.TunnelPort);
        return (cliente.TunnelPort, emp?.Codigo ?? 1);
    }

    public async Task<IActionResult> OnGetAsync(string? de, string? ate)
    {
        // [v7] Permissão (vazio = acesso total; contador pode ter SÓ isto liberado)
        if (!Permissao.Tem(User, Permissao.XmlSaida))
        {
            Aviso = "Seu usuário não tem acesso à exportação de XML.";
            return Page();
        }

        De  = !string.IsNullOrEmpty(de)  ? de  : DateTime.Today.AddDays(-30).ToString("yyyy-MM-dd");
        Ate = !string.IsNullOrEmpty(ate) ? ate : DateTime.Today.ToString("yyyy-MM-dd");

        var loja = await ResolverLojaAsync();
        if (loja == null)
        {
            Aviso = "Canal de dados não configurado para esta loja.";
            return Page();
        }

        Resumo = await _api.XmlSaidaResumoAsync(loja.Value.Porta, loja.Value.Empresa, De, Ate);
        if (Resumo == null)
            Aviso = "A loja está offline no momento. Tente novamente quando estiver conectada.";
        return Page();
    }

    /// <summary>Handler do botão de download: /XmlSaida?handler=Baixar&de=...&ate=...</summary>
    public async Task<IActionResult> OnGetBaixarAsync(string de, string ate)
    {
        if (!Permissao.Tem(User, Permissao.XmlSaida))
        {
            Aviso = "Seu usuário não tem acesso à exportação de XML.";
            return Page();
        }
        De = de; Ate = ate;
        var loja = await ResolverLojaAsync();
        if (loja == null)
        {
            Aviso = "Canal de dados não configurado para esta loja.";
            return Page();
        }

        var zip = await _api.XmlSaidaZipAsync(loja.Value.Porta, loja.Value.Empresa, de, ate);
        if (zip == null)
        {
            Resumo = await _api.XmlSaidaResumoAsync(loja.Value.Porta, loja.Value.Empresa, de, ate);
            Aviso = "Não foi possível gerar o ZIP (loja offline ou nenhuma nota no período).";
            return Page();
        }

        return File(zip.Value.Dados, "application/zip", zip.Value.Nome);
    }
}
