using System.Text.Json;
using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[Authorize]
public class DashboardModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public DashboardModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public record Card(string Icone, string Label, string Key, string Tipo, string Cor); // Tipo: money|int|min
    public record Col(string Label, string Key, string Tipo);                              // Tipo: money|int|min|texto
    public record Tabela(string Titulo, string ArrayKey, Col[] Cols);

    public string Tipo { get; private set; } = "balcao";
    public string Titulo { get; private set; } = "";
    public string Cor { get; private set; } = "#0d3b66";
    public string Loja { get; private set; } = "";
    public string De { get; set; } = "";
    public string Ate { get; set; } = "";
    public string? Aviso { get; private set; }
    public List<Card> Cards { get; private set; } = new();
    public List<Tabela> Tabelas { get; private set; } = new();
    public JsonElement Dados { get; private set; }
    private bool _temDados;

    private static readonly System.Globalization.NumberFormatInfo BrNum = new()
    { NumberDecimalSeparator = ",", NumberGroupSeparator = "." };

    public async Task<IActionResult> OnGetAsync(string tipo, string? de, string? ate)
    {
        // [v7] Permissão (vazio = acesso total)
        if (!Permissao.Tem(User, Permissao.Dashboards))
            return RedirectToPage("/Index");

        Tipo = (tipo ?? "balcao").ToLowerInvariant();
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";
        Configurar();

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null || cliente.TunnelPort <= 0) { Aviso = "Canal de dados não configurado para esta loja."; return Page(); }

        De = !string.IsNullOrEmpty(de) ? de : DateTime.Today.ToString("yyyy-MM-dd");
        Ate = !string.IsNullOrEmpty(ate) ? ate : DateTime.Today.ToString("yyyy-MM-dd");

        var emp = await _api.EmpresaAsync(cliente.TunnelPort);
        var empresa = emp?.Codigo ?? 1;

        var raw = await _api.GetRawAsync(cliente.TunnelPort, $"/api/dash/{Tipo}?empresa={empresa}&de={De}&ate={Ate}");
        if (raw == null) { Aviso = "A loja está offline no momento ou a versão dela ainda não tem os dashboards (atualize o sistema da loja)."; return Page(); }
        try
        {
            var doc = JsonDocument.Parse(raw);
            Dados = doc.RootElement.Clone();
            _temDados = Dados.TryGetProperty("ok", out var ok) && ok.ValueKind == JsonValueKind.True;
            if (!_temDados) Aviso = "Não foi possível obter os dados do dashboard.";
        }
        catch { Aviso = "Resposta inválida da loja."; }
        return Page();
    }

    public bool TemDados => _temDados;

    public string Valor(string key, string tipo)
    {
        try
        {
            if (!Dados.TryGetProperty(key, out var el)) return tipo == "money" ? "R$ 0,00" : "0";
            return Formatar(el, tipo);
        }
        catch { return tipo == "money" ? "R$ 0,00" : "0"; }
    }

    public IEnumerable<JsonElement> Linhas(string arrayKey)
    {
        if (Dados.ValueKind == JsonValueKind.Object && Dados.TryGetProperty(arrayKey, out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var e in arr.EnumerateArray()) yield return e;
    }

    public string Celula(JsonElement linha, string key, string tipo)
    {
        try { return linha.TryGetProperty(key, out var el) ? Formatar(el, tipo) : ""; }
        catch { return ""; }
    }

    private static string Formatar(JsonElement el, string tipo)
    {
        switch (tipo)
        {
            case "money":
                return "R$ " + (el.ValueKind == JsonValueKind.Number ? el.GetDecimal() : 0m).ToString("N2", BrNum);
            case "min":
                var m = el.ValueKind == JsonValueKind.Number ? el.GetInt32() : 0;
                return m > 0 ? m + " min" : "-";
            case "int":
                if (el.ValueKind == JsonValueKind.Number) return ((decimal)el.GetDecimal()).ToString("0.##", BrNum);
                return el.ToString();
            default:
                return el.ValueKind == JsonValueKind.String ? el.GetString() ?? "" : el.ToString();
        }
    }

    private void Configurar()
    {
        switch (Tipo)
        {
            case "delivery":
                Titulo = "Dashboard Delivery"; Cor = "#ea580c";
                Cards = new()
                {
                    new("⏳","PENDENTES","pendentes","int","#f59e0b"),
                    new("✅","PRONTOS","prontos","int","#0ea5e9"),
                    new("🛵","SAIU P/ ENTREGA","saiu","int","#ea580c"),
                    new("📦","ENTREGUES","entregues","int","#22a05a"),
                    new("✖","CANCELADOS","cancelados","int","#787878"),
                    new("📊","PEDIDOS TOTAL","totalDia","int","#7c3aed"),
                    new("💰","FATURAMENTO","faturamento","money","#228b22"),
                    new("🧮","TICKET MÉDIO","ticket","money","#1e40af"),
                    new("⏱","TEMPO MÉDIO","tempoMedio","min","#a8581c"),
                };
                Tabelas = new()
                {
                    new("TOP 5 BAIRROS (mais pedidos no período)","topBairros", new[]{
                        new Col("Bairro","bairro","texto"), new Col("Pedidos","pedidos","int"),
                        new Col("Faturamento","total","money"), new Col("Tempo (min)","tempo","int")}),
                    new("TOP 5 ENTREGADORES (no período)","topEntregadores", new[]{
                        new Col("Entregador","entregador","texto"), new Col("Entregas","entregas","int"),
                        new Col("Tempo (min)","tempo","int"), new Col("Comissão","comissao","money")}),
                };
                break;
            case "mesas":
                Titulo = "Dashboard Mapa de Mesas"; Cor = "#1e40af";
                Cards = new()
                {
                    new("📂","ABERTOS","abertos","int","#ea580c"),
                    new("✅","FECHADOS","fechados","int","#22a05a"),
                    new("✖","CANCELADOS","cancelados","int","#787878"),
                    new("📊","TOTAL","total","int","#7c3aed"),
                    new("💰","FATURAMENTO","faturamento","money","#228b22"),
                    new("🧮","TICKET MÉDIO","ticket","money","#1e40af"),
                    new("🛎","TAXA SERVIÇO","taxaServico","money","#7c3aed"),
                    new("🎭","COUVERT","couvert","money","#dc6432"),
                };
                Tabelas = new()
                {
                    new("TOP 5 GARÇONS (por pedidos no período)","topGarcons", new[]{
                        new Col("Garçom","garcom","texto"), new Col("Pedidos","pedidos","int"),
                        new Col("Faturamento","total","money"), new Col("Ticket Méd.","ticket","money")}),
                    new("TOP 5 MESAS MAIS MOVIMENTADAS (no período)","topMesas", new[]{
                        new Col("Mesa","mesa","texto"), new Col("Pedidos","pedidos","int"),
                        new Col("Itens","itens","int"), new Col("Faturamento","total","money")}),
                };
                break;
            default:
                Tipo = "balcao"; Titulo = "Dashboard Vendas - Balcão"; Cor = "#059669";
                Cards = new()
                {
                    new("🧾","VENDAS","vendas","int","#059669"),
                    new("📦","ITENS","itens","int","#7c3aed"),
                    new("💰","FATURAMENTO","faturamento","money","#228b22"),
                    new("🧮","TICKET MÉDIO","ticket","money","#1e40af"),
                    new("🔻","DESCONTOS","descontos","money","#ea580c"),
                    new("✖","CANCELADAS","cancelados","int","#787878"),
                };
                Tabelas = new()
                {
                    new("TOP 5 PRODUTOS MAIS VENDIDOS (no período)","topProdutos", new[]{
                        new Col("Produto","produto","texto"), new Col("Qtd","qtd","int"),
                        new Col("Faturamento","total","money"), new Col("Vendas","vendas","int")}),
                    new("TOP 5 VENDEDORES (no período)","topVendedores", new[]{
                        new Col("Vendedor","vendedor","texto"), new Col("Vendas","vendas","int"),
                        new Col("Faturamento","total","money"), new Col("Ticket Méd.","ticket","money")}),
                };
                break;
        }
    }
}
