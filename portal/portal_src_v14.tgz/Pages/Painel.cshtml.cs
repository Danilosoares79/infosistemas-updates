using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using InfoSistemas.Portal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[Authorize]
public class PainelModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public PainelModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public string Loja { get; private set; } = "";
    public bool Disponivel { get; private set; }
    public string? Aviso { get; private set; }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true"))
            return RedirectToPage("/Admin/Index");

        // [v7] Permissão (vazio = acesso total)
        if (!Permissao.Tem(User, Permissao.Painel))
            return RedirectToPage("/Index");

        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";
        var cliente = await ClienteAtualAsync();
        if (cliente == null || cliente.TunnelPort <= 0)
        {
            Aviso = "O canal de dados desta loja ainda não foi configurado.";
            return Page();
        }
        Disponivel = true;
        return Page();
    }

    // Handler chamado pelo JavaScript (polling) → agrega os 3 endpoints da loja.
    public async Task<IActionResult> OnGetDadosAsync()
    {
        var cliente = await ClienteAtualAsync();
        if (cliente == null || cliente.TunnelPort <= 0)
            return Content("{\"ok\":false,\"motivo\":\"sem_canal\"}", "application/json");

        var porta = cliente.TunnelPort;
        var emp = await _api.EmpresaAsync(porta);
        var empresa = emp?.Codigo ?? 1;

        var resumo = await _api.GetRawAsync(porta, $"/api/painel/resumo?empresa={empresa}");
        var mesas = await _api.GetRawAsync(porta, $"/api/painel/mesas?empresa={empresa}");
        var delivery = await _api.GetRawAsync(porta, $"/api/painel/delivery?empresa={empresa}");

        if (resumo == null && mesas == null && delivery == null)
            return Content("{\"ok\":false,\"motivo\":\"offline\"}", "application/json");

        var json = "{\"ok\":true," +
                   $"\"resumo\":{resumo ?? "null"}," +
                   $"\"mesas\":{mesas ?? "null"}," +
                   $"\"delivery\":{delivery ?? "null"}}}";
        return Content(json, "application/json");
    }

    private async Task<Cliente?> ClienteAtualAsync()
    {
        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        return clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
    }
}
