using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[Authorize]
public class IndexModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public IndexModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public string Loja { get; private set; } = "";
    public List<CatalogoItem> Relatorios { get; private set; } = new();
    public string? Aviso { get; private set; }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true"))
            return RedirectToPage("/Admin/Index");

        // [v7] Usuário restrito SEM nenhum relatório liberado (ex.: contador só com
        // XML Saída) → vai direto para a página que ele pode usar.
        if (Permissao.Restrito(User))
        {
            var perms = (User.FindFirst("perms")?.Value ?? "")
                .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var temRel = perms.Any(p => p.StartsWith("REL:", StringComparison.OrdinalIgnoreCase));
            if (!temRel && Permissao.Tem(User, Permissao.XmlSaida))
                return RedirectToPage("/XmlSaida");
        }

        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;

        if (cliente == null || cliente.TunnelPort <= 0)
        {
            Aviso = "O canal de dados desta loja ainda não foi configurado. Fale com o suporte.";
            return Page();
        }

        Relatorios = await _api.CatalogoAsync(cliente.TunnelPort);

        // [v7] Filtra pelo que o usuário pode ver (vazio = acesso total)
        if (Permissao.Restrito(User))
            Relatorios = Relatorios.Where(r => Permissao.TemRelatorio(User, r.Id)).ToList();

        if (Relatorios.Count == 0)
            Aviso = Permissao.Restrito(User)
                ? "Seu usuário não tem relatórios liberados. Fale com o responsável pela loja."
                : "A loja está offline no momento (sistema fechado ou sem internet). " +
                  "Os relatórios aparecem assim que a loja estiver conectada.";
        return Page();
    }
}
