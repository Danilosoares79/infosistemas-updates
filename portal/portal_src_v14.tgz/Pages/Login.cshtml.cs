using System.Security.Claims;
using InfoSistemas.Portal.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

[AllowAnonymous]
public class LoginModel : PageModel
{
    private readonly Db _db;
    public LoginModel(Db db) => _db = db;

    [BindProperty] public string? Cnpj { get; set; }
    [BindProperty] public string Login { get; set; } = "";
    [BindProperty] public string Senha { get; set; } = "";
    public string? Erro { get; set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        var u = await _db.AutenticarAsync(Cnpj, Login.Trim(), Senha);
        if (u == null)
        {
            Erro = "CNPJ, usuário ou senha inválidos.";
            return Page();
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, u.Login),
            new("uid", u.Id.ToString()),
            new("is_admin", u.IsAdmin ? "true" : "false"),
        };
        if (u.FkCliente.HasValue)
            claims.Add(new Claim("cliente_id", u.FkCliente.Value.ToString()));
        if (!string.IsNullOrEmpty(u.ClienteRazao))
            claims.Add(new Claim("razao", u.ClienteRazao!));
        // [v7] permissões (vazio = acesso total). Mudanças valem no próximo login.
        claims.Add(new Claim("perms", u.Permissoes ?? ""));

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity));

        return u.IsAdmin ? RedirectToPage("/Admin/Index") : RedirectToPage("/Index");
    }
}
