using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Models;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages.Admin;

/// <summary>[ETAPA 3 — Retaguarda Web] Status de sincronização de TODAS as lojas.</summary>
[Authorize(Policy = "AdminOnly")]
public class SincronizacaoModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public SincronizacaoModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public sealed record Linha(Cliente Cliente, SyncStore.ReplicaStatus? Status);
    public List<Linha> Linhas { get; private set; } = new();

    public async Task OnGetAsync()
    {
        foreach (var c in await _db.ListarClientesAsync())
            Linhas.Add(new Linha(c, await _sync.StatusTipadoAsync(c.Cnpj)));
    }

    public static string Farol(SyncStore.ReplicaStatus? s)
    {
        if (s == null || s.CargaFeita != "S") return "—";
        if (s.UltimaSync == null) return "—";
        var idade = DateTime.Now - s.UltimaSync.Value;
        return idade.TotalMinutes <= 10 ? "🟢" : idade.TotalHours <= 24 ? "🟡" : "🔴";
    }
}
