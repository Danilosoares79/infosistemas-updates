using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Models;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages.Admin;

[Authorize(Policy = "AdminOnly")]
public class IndexModel : PageModel
{
    private readonly Db _db;
    private readonly LojaApiClient _api;
    public IndexModel(Db db, LojaApiClient api) { _db = db; _api = api; }

    public List<Cliente> Clientes { get; private set; } = new();
    public List<Usuario> Usuarios { get; private set; } = new();

    // [v7] Pesquisa de clientes: ?q=... → lojas filtradas com os usuários de cada
    // uma + editor de permissões (catálogo de relatórios buscado da loja online).
    [BindProperty(SupportsGet = true)] public string? Q { get; set; }
    public List<Cliente> ClientesBusca { get; private set; } = new();
    public Dictionary<int, List<Usuario>> UsuariosPorCliente { get; private set; } = new();
    public Dictionary<int, List<CatalogoItem>> CatalogoPorCliente { get; private set; } = new();

    [TempData] public string? Msg { get; set; }
    [TempData] public string? MsgErro { get; set; }

    public async Task OnGetAsync() => await CarregarAsync();

    private async Task CarregarAsync()
    {
        Clientes = await _db.ListarClientesAsync();
        Usuarios = await _db.ListarUsuariosAsync();

        var q = (Q ?? "").Trim();
        if (q.Length == 0) return;

        var dig = Db.SoDigitos(q);
        ClientesBusca = Clientes.Where(c =>
                c.RazaoSocial.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                (dig.Length > 0 && c.Cnpj.Contains(dig)))
            .Take(6).ToList();

        foreach (var c in ClientesBusca)
        {
            UsuariosPorCliente[c.Id] = Usuarios.Where(u => u.FkCliente == c.Id).ToList();
            // Catálogo ao vivo da loja (vazio = offline → só as permissões fixas)
            CatalogoPorCliente[c.Id] = c.TunnelPort > 0
                ? await _api.CatalogoAsync(c.TunnelPort)
                : new List<CatalogoItem>();
        }
    }

    /// <summary>Tokens de permissão do usuário (para pré-marcar os checkboxes).</summary>
    public static HashSet<string> Tokens(Usuario u) =>
        new((u.Permissoes ?? "").Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
            StringComparer.OrdinalIgnoreCase);

    /// <summary>[v7] Salva permissões. modo=total → acesso total (limpa).
    /// modo=custom → só os tokens marcados; se a loja estava offline
    /// (manterRel=1) os REL: já existentes são preservados.</summary>
    public async Task<IActionResult> OnPostPermissoesAsync(int usuarioId, string modo,
        string[]? perm, int manterRel = 0)
    {
        if (modo == "total")
        {
            await _db.AtualizarPermissoesAsync(usuarioId, null);
            Msg = "Permissões salvas: ACESSO TOTAL. Vale no próximo login do usuário.";
            return RedirectToPage(new { q = Q });
        }

        var tokens = new List<string>(perm ?? Array.Empty<string>());
        if (manterRel == 1)
        {
            // loja offline: preserva os relatórios já liberados anteriormente
            var atuais = await _db.ObterPermissoesAsync(usuarioId) ?? "";
            tokens.AddRange(atuais.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                                  .Where(t => t.StartsWith("REL:", StringComparison.OrdinalIgnoreCase)));
        }
        var final = string.Join(';', tokens.Where(t => !string.IsNullOrWhiteSpace(t))
                                           .Distinct(StringComparer.OrdinalIgnoreCase));
        if (string.IsNullOrWhiteSpace(final))
        {
            // restrito sem NADA marcado seria um usuário que não vê nada — bloqueia por engano
            MsgErro = "Marque pelo menos um item (ou escolha Acesso total).";
            return RedirectToPage(new { q = Q });
        }
        await _db.AtualizarPermissoesAsync(usuarioId, final);
        Msg = "Permissões salvas. Valem no próximo login do usuário.";
        return RedirectToPage(new { q = Q });
    }

    public async Task<IActionResult> OnPostNovoClienteAsync(string cnpj, string razao, int tunnelPort)
    {
        var dig = Db.SoDigitos(cnpj);
        if (dig.Length != 14 && dig.Length != 11)
        {
            MsgErro = "Documento inválido: informe um CNPJ (14 dígitos) ou CPF (11 dígitos).";
            return RedirectToPage();
        }
        await _db.SalvarClienteAsync(new Cliente
        {
            Cnpj = dig,
            RazaoSocial = (razao ?? "").Trim(),
            Ativo = true,
            TunnelPort = tunnelPort,
        });
        Msg = "Loja cadastrada.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostNovoUsuarioAsync(int clienteId, string login, string senha,
        string nome, string? perfil)
    {
        if (clienteId <= 0 || string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(senha))
        {
            MsgErro = "Preencha loja, usuário e senha.";
            return RedirectToPage(new { q = Q });
        }
        // [v7] Perfis rápidos: total (padrão) | xml (contador: SÓ Exportar XML Saída)
        var permissoes = perfil == "xml" ? Permissao.XmlSaida : null;
        try
        {
            await _db.CriarUsuarioAsync(clienteId, login.Trim(), senha, (nome ?? "").Trim(), false, permissoes);
            Msg = permissoes == null
                ? "Usuário criado com ACESSO TOTAL."
                : "Usuário criado com acesso SOMENTE à exportação de XML (contador). " +
                  "Ajuste fino: pesquise a loja e clique em Permissões.";
        }
        catch
        {
            MsgErro = "Não foi possível criar (login já existe para essa loja?).";
        }
        return RedirectToPage(new { q = Q });
    }

    public async Task<IActionResult> OnPostResetSenhaAsync(int usuarioId, string novaSenha)
    {
        if (string.IsNullOrWhiteSpace(novaSenha))
        {
            MsgErro = "Informe a nova senha.";
            return RedirectToPage();
        }
        await _db.RedefinirSenhaAsync(usuarioId, novaSenha);
        Msg = "Senha redefinida.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostToggleUsuarioAsync(int usuarioId, bool ativo)
    {
        await _db.DefinirAtivoUsuarioAsync(usuarioId, ativo);
        Msg = ativo ? "Usuário ativado." : "Usuário desativado.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditarClienteAsync(int id, string razao, bool ativo, int tunnelPort)
    {
        if (string.IsNullOrWhiteSpace(razao)) { MsgErro = "Razão social é obrigatória."; return RedirectToPage(); }
        await _db.AtualizarClienteAsync(id, razao, ativo, tunnelPort);
        Msg = "Loja atualizada.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditarUsuarioAsync(int id, string login, string nome)
    {
        if (string.IsNullOrWhiteSpace(login)) { MsgErro = "Usuário é obrigatório."; return RedirectToPage(); }
        try { await _db.AtualizarUsuarioAsync(id, login, nome); Msg = "Usuário atualizado."; }
        catch { MsgErro = "Não foi possível atualizar (login já existe para essa loja?)."; }
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostAdminSenhaAsync(string novaSenha)
    {
        if (string.IsNullOrWhiteSpace(novaSenha) || novaSenha.Trim().Length < 6)
        { MsgErro = "A senha do admin precisa de pelo menos 6 caracteres."; return RedirectToPage(); }
        await _db.AlterarSenhaAdminAsync(novaSenha.Trim());
        Msg = "Senha do admin alterada com sucesso.";
        return RedirectToPage();
    }
}
