namespace InfoSistemas.Portal;

/// <summary>Cardápio mobile do autoatendimento (HTML), servido em /menu/{loja}/{token}.</summary>
public static class MenuPage
{
    public static string Html(string loja, string token)
    {
        var safeLoja = System.Text.RegularExpressions.Regex.Replace(loja ?? "", "[^0-9]", "");
        var safeTok = System.Text.RegularExpressions.Regex.Replace(token ?? "", "[^a-zA-Z0-9]", "");
        return TEMPLATE.Replace("__LOJA__", safeLoja).Replace("__TOKEN__", safeTok);
    }

    private const string TEMPLATE = """
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Cardápio</title>
<style>
:root{--cor:#0d3b66;--btn:#1b7f4b}
*{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif}
body{background:#f4f6fb;color:#1e293b;padding-bottom:88px}
#marca{position:fixed;inset:0;background-repeat:no-repeat;background-position:center 46%;background-size:68%;opacity:.06;z-index:0;pointer-events:none;display:none}
#app{position:relative;z-index:1}
.top{background:var(--cor);color:#fff;padding:14px 18px;position:sticky;top:0;z-index:5;text-align:center}
.top .logo{height:56px;max-width:75%;object-fit:contain;display:none;margin:0 auto 6px;background:#fff;border-radius:8px;padding:4px}
.top h1{font-size:18px}.top .mesa{font-size:13px;opacity:.9;margin-top:2px}
.grupo{font-size:15px;font-weight:700;color:var(--cor);padding:16px 16px 6px}
.prod{background:#fff;margin:6px 12px;border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:12px;box-shadow:0 1px 2px rgba(0,0,0,.06)}
.pfoto{width:92px;height:92px;border-radius:10px;object-fit:cover;flex-shrink:0;background:#eef2f7;cursor:pointer}
.pinfo{flex:1}.pnome{font-weight:600}.pdesc{font-size:12px;color:#64748b;margin-top:2px}.ppreco{color:var(--btn);font-weight:700;margin-top:4px}
.add{background:var(--btn);color:#fff;border:0;width:40px;height:40px;border-radius:10px;font-size:22px;font-weight:700;cursor:pointer}
.bar{position:fixed;left:0;right:0;bottom:0;background:#fff;box-shadow:0 -2px 8px rgba(0,0,0,.12);padding:10px 12px;display:none;gap:10px;z-index:20}
.bar button{flex:1;border:0;border-radius:10px;padding:12px;font-size:14px;font-weight:700;cursor:pointer}
.bar .conta{background:#eef2f7;color:#0d3b66}
.bar .ped{background:var(--btn);color:#fff}
.bar .ped:disabled{background:#cbd5e1;color:#fff}
.msg{padding:40px 24px;text-align:center;font-size:16px;color:#334155}.msg.ok{color:var(--btn);font-weight:600;font-size:18px}
.toast{position:fixed;bottom:96px;left:50%;transform:translateX(-50%);background:#111;color:#fff;padding:8px 16px;border-radius:20px;font-size:13px;opacity:0;transition:.3s;z-index:60}
.toast.show{opacity:.92}
.consulta{background:#fff7ed;color:#9a3412;text-align:center;padding:8px;font-size:13px}
.lightbox{position:fixed;inset:0;background:rgba(0,0,0,.88);display:none;align-items:center;justify-content:center;z-index:80;padding:14px}
.lightbox img{width:92vw;max-width:560px;max-height:88vh;object-fit:contain;border-radius:12px;box-shadow:0 6px 30px rgba(0,0,0,.5)}
.lightbox .fechar{position:absolute;top:12px;right:16px;color:#fff;font-size:34px;font-weight:700;line-height:1}
.ov{position:fixed;inset:0;background:rgba(0,0,0,.45);display:none;z-index:40}
.sheet{position:fixed;left:0;right:0;bottom:0;max-height:85vh;background:#fff;border-radius:16px 16px 0 0;display:none;flex-direction:column;z-index:45;box-shadow:0 -4px 20px rgba(0,0,0,.2)}
.sheet .sh{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid #eef2f7}
.sheet .sh h2{font-size:16px}.sheet .sh .x{font-size:26px;color:#64748b;cursor:pointer;line-height:1}
.sheet .sb{overflow:auto;padding:8px 14px;flex:1}
.sheet .sf{padding:12px 14px;border-top:1px solid #eef2f7}
.linha{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f1f5f9}
.linha .ln{flex:1}.linha .lnome{font-weight:600;font-size:14px}.linha .lsub{font-size:12px;color:#64748b}
.qtd{display:flex;align-items:center;gap:8px}
.qtd button{width:30px;height:30px;border:0;border-radius:8px;background:#eef2f7;font-size:18px;font-weight:700;cursor:pointer}
.lrem{color:#dc2626;font-size:12px;background:none;border:0;cursor:pointer}
.tot{display:flex;justify-content:space-between;font-size:14px;padding:3px 0}
.tot.g{font-weight:700;font-size:16px;border-top:1px solid #e2e8f0;margin-top:6px;padding-top:8px}
.btnp{width:100%;background:var(--btn);color:#fff;border:0;border-radius:10px;padding:14px;font-size:16px;font-weight:700;cursor:pointer}
.btnp:disabled{background:#cbd5e1}
.sechead{font-weight:700;color:var(--cor);margin:6px 0 2px;font-size:14px}
.vazio{color:#94a3b8;text-align:center;padding:18px;font-size:14px}
</style>
</head>
<body>
<div id="marca"></div>
<div id="app">
  <div class="top"><img class="logo" id="logo" src="" alt=""><h1 id="estab">Carregando…</h1><div class="mesa" id="mesa"></div></div>
  <div id="consulta"></div>
  <div id="lista"><div class="msg">Carregando cardápio…</div></div>
</div>

<div class="bar" id="bar">
  <button class="conta" onclick="abrirSheet('conta')">🧾 Minha conta</button>
  <button class="ped" id="bped" onclick="abrirSheet('cart')">🛒 Pedido · <span id="bq">0</span> · <span id="bt">R$ 0,00</span></button>
</div>

<div class="ov" id="ov" onclick="fecharSheet()"></div>
<div class="sheet" id="sheet">
  <div class="sh"><h2 id="shtit">Pedido</h2><span class="x" onclick="fecharSheet()">&times;</span></div>
  <div class="sb" id="shbody"></div>
  <div class="sf" id="shfoot"></div>
</div>

<div class="toast" id="toast"></div>
<div class="lightbox" id="lightbox" onclick="this.style.display='none'"><span class="fechar">&times;</span><img id="lbimg" src="" alt=""></div>

<script>
const LOJA="__LOJA__",TOKEN="__TOKEN__",API="/auto/"+LOJA;
let cart={},PRECO=true,MODO=true,FOTOS=true;
function brl(v){return 'R$ '+(Number(v)||0).toFixed(2).replace('.',',');}
function abrirFoto(src){var lb=document.getElementById('lightbox');document.getElementById('lbimg').src=src;lb.style.display='flex';}
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1200);}
function esc(s){return (s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

async function load(){
  try{
    const r=await fetch(`${API}/cardapio/${TOKEN}`);const j=await r.json();
    if(!j.ok){document.getElementById('lista').innerHTML='<div class="msg">'+(j.mensagem||'Cardápio indisponível.')+'</div>';return;}
    render(j.dados);
    document.getElementById('bar').style.display='flex';
  }catch(e){document.getElementById('lista').innerHTML='<div class="msg">Loja offline. Tente novamente em instantes.</div>';}
}
function render(d){
  const tema=d.tema||{},mesa=d.mesa||{};
  if(tema.corPrimaria)document.documentElement.style.setProperty('--cor',tema.corPrimaria);
  if(tema.botaoCor)document.documentElement.style.setProperty('--btn',tema.botaoCor);
  PRECO=tema.mostrarPrecos!==false;MODO=d.modoPedido!==false;FOTOS=tema.mostrarFotos!==false;
  document.getElementById('estab').textContent=tema.nomeEstabelecimento||'Cardápio';
  document.getElementById('mesa').textContent=mesa.nome?('Mesa: '+mesa.nome):'';
  if(tema.logoBase64){var ls=(''+tema.logoBase64).indexOf('data:')===0?tema.logoBase64:('data:image/png;base64,'+tema.logoBase64);var lg=document.getElementById('logo');lg.src=ls;lg.style.display='block';var mc=document.getElementById('marca');mc.style.backgroundImage='url('+ls+')';mc.style.display='block';}
  if(!MODO){document.getElementById('consulta').innerHTML='<div class="consulta">Cardápio em modo consulta — peça ao garçom.</div>';document.getElementById('bped').style.display='none';}
  const cont=document.getElementById('lista');cont.innerHTML='';
  const grupos=d.grupos||[],prods=(d.produtos||[]).filter(p=>p.disponivel!==false);
  const usados=new Set();
  grupos.forEach(g=>{
    const ps=prods.filter(p=>p.grupo===g.codigo);if(ps.length===0)return;
    const h=document.createElement('div');h.className='grupo';h.textContent=((g.emoji||'')+' '+g.descricao).trim();cont.appendChild(h);
    ps.forEach(p=>{usados.add(p.codigo);cont.appendChild(card(p));});
  });
  const outros=prods.filter(p=>!usados.has(p.codigo));
  if(outros.length){const h=document.createElement('div');h.className='grupo';h.textContent='Outros';cont.appendChild(h);outros.forEach(p=>cont.appendChild(card(p)));}
  if(!cont.children.length)cont.innerHTML='<div class="msg">Nenhum produto disponível.</div>';
}
function card(p){
  const el=document.createElement('div');el.className='prod';
  var foto='';
  if(FOTOS && p.fotoBase64){var src=(''+p.fotoBase64).indexOf('data:')===0?p.fotoBase64:('data:image/jpeg;base64,'+p.fotoBase64);foto='<img class="pfoto" loading="lazy" onclick="abrirFoto(this.src)" src="'+src+'" alt="">';}
  el.innerHTML=foto+'<div class="pinfo"><div class="pnome">'+esc(p.descricao)+'</div>'+
    (p.descricao2?'<div class="pdesc">'+esc(p.descricao2)+'</div>':'')+
    (PRECO?'<div class="ppreco">'+brl(p.preco)+'</div>':'')+'</div>';
  if(MODO){const b=document.createElement('button');b.className='add';b.textContent='+';b.onclick=()=>addCart(p);el.appendChild(b);}
  return el;
}
function addCart(p){const c=cart[p.codigo]||{cod:p.codigo,desc:p.descricao,preco:Number(p.preco)||0,qtd:0};c.qtd++;cart[p.codigo]=c;bar();toast(p.descricao+' adicionado');}
function inc(cod){cart[cod].qtd++;bar();if(sheetModo==='cart')renderCart();}
function dec(cod){if(!cart[cod])return;cart[cod].qtd--;if(cart[cod].qtd<=0)delete cart[cod];bar();if(sheetModo==='cart')renderCart();}
function rem(cod){delete cart[cod];bar();if(sheetModo==='cart')renderCart();}
function cartTot(){const it=Object.values(cart);return {q:it.reduce((s,c)=>s+c.qtd,0),t:it.reduce((s,c)=>s+c.qtd*c.preco,0),it};}
function bar(){const x=cartTot();document.getElementById('bq').textContent=x.q;document.getElementById('bt').textContent=brl(x.t);document.getElementById('bped').disabled=x.q===0;}

let sheetModo='cart';
function abrirSheet(modo){sheetModo=modo;document.getElementById('ov').style.display='block';document.getElementById('sheet').style.display='flex';if(modo==='cart')renderCart();else renderConta();}
function fecharSheet(){document.getElementById('ov').style.display='none';document.getElementById('sheet').style.display='none';}

function renderCart(){
  document.getElementById('shtit').textContent='Seu pedido';
  const x=cartTot();const b=document.getElementById('shbody');
  if(x.it.length===0){b.innerHTML='<div class="vazio">Seu carrinho está vazio.<br>Toque em + nos itens do cardápio.</div>';document.getElementById('shfoot').innerHTML='';return;}
  b.innerHTML=x.it.map(c=>'<div class="linha"><div class="ln"><div class="lnome">'+esc(c.desc)+'</div><div class="lsub">'+brl(c.preco)+' · <button class="lrem" onclick="rem('+c.cod+')">remover</button></div></div>'+
    '<div class="qtd"><button onclick="dec('+c.cod+')">−</button><b>'+c.qtd+'</b><button onclick="inc('+c.cod+')">+</button></div>'+
    '<div style="width:74px;text-align:right;font-weight:700">'+brl(c.preco*c.qtd)+'</div></div>').join('');
  document.getElementById('shfoot').innerHTML='<div class="tot g"><span>Total do pedido</span><span>'+brl(x.t)+'</span></div>'+
    '<button class="btnp" id="send" onclick="enviar()" style="margin-top:10px">Enviar pedido</button>';
}

async function renderConta(){
  document.getElementById('shtit').textContent='Consumo da mesa';
  const b=document.getElementById('shbody');b.innerHTML='<div class="vazio">Carregando…</div>';
  document.getElementById('shfoot').innerHTML='<button class="btnp" onclick="renderConta()" style="background:#eef2f7;color:#0d3b66">Atualizar</button>';
  try{
    const r=await fetch(`${API}/conta/${TOKEN}`);const j=await r.json();
    const c=j.dados;
    if(!j.ok || !c || !c.itens || c.itens.length===0){b.innerHTML='<div class="vazio">Nenhum item lançado na mesa ainda.</div>';return;}
    let h='<div class="sechead">Itens já lançados</div>';
    h+=c.itens.map(i=>'<div class="linha"><div class="ln"><div class="lnome">'+esc(i.descricao)+'</div><div class="lsub">'+(Number(i.quantidade)||0)+' x '+brl(i.valorUnit)+(i.obs?(' · '+esc(i.obs)):'')+'</div></div><div style="font-weight:700">'+brl(i.valorTotal)+'</div></div>').join('');
    h+='<div style="margin-top:10px"><div class="tot"><span>Subtotal</span><span>'+brl(c.subtotal)+'</span></div>';
    if(Number(c.valorServico)>0)h+='<div class="tot"><span>Serviço</span><span>'+brl(c.valorServico)+'</span></div>';
    h+='<div class="tot g"><span>Total</span><span>'+brl(c.totalGeral)+'</span></div></div>';
    b.innerHTML=h;
  }catch(e){b.innerHTML='<div class="vazio">Não foi possível carregar a conta agora.</div>';}
}

async function enviar(){
  const x=cartTot();if(x.it.length===0)return;
  const btn=document.getElementById('send');if(btn){btn.disabled=true;btn.textContent='Enviando…';}
  try{
    for(const c of x.it){
      const r=await fetch(`${API}/pedido/${TOKEN}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({fkProduto:c.cod,quantidade:c.qtd,obs:''})});
      const j=await r.json();if(!j.ok)throw new Error(j.mensagem||'erro');
    }
    const rc=await fetch(`${API}/confirmar/${TOKEN}`,{method:'POST'});const jc=await rc.json();
    cart={};bar();
    document.getElementById('shtit').textContent='Pedido enviado';
    document.getElementById('shbody').innerHTML='<div class="msg ok">✅ '+(jc.mensagem||'Pedido enviado! Aguarde.')+'</div>';
    document.getElementById('shfoot').innerHTML='<button class="btnp" onclick="renderConta()">Ver consumo da mesa</button>';
  }catch(e){alert('Não foi possível enviar: '+(e.message||'tente novamente.'));if(btn){btn.disabled=false;btn.textContent='Enviar pedido';}}
}
load();
</script>
</body>
</html>
""";
}
