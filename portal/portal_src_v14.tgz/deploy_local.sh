#!/usr/bin/env bash
# Deploy LOCAL do Portal (codigo ja extraido em /opt/infosistemas/portal-app).
# Uso:  sudo ADMIN_SENHA='SuaSenha' bash deploy_local.sh
set -euo pipefail

APPDIR="$(cd "$(dirname "$0")" && pwd)"
SECRETS=/opt/infosistemas/portal/secrets.env
ENVFILE=/opt/infosistemas/portal/.env

if [ -z "${ADMIN_SENHA:-}" ]; then
  echo "ERRO: defina a senha do admin. Ex:  sudo ADMIN_SENHA='SuaSenha' bash deploy_local.sh"; exit 1
fi

echo ">> [1/5] Descobrindo senha do MySQL, rede Docker e token do portal..."
MYSQL_PASSWORD=""
for f in "$SECRETS" "$ENVFILE"; do
  if [ -f "$f" ]; then
    v=$(grep -E '^MYSQL_PASSWORD=' "$f" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"' || true)
    [ -n "$v" ] && MYSQL_PASSWORD="$v"
  fi
done
[ -z "$MYSQL_PASSWORD" ] && { echo "ERRO: MYSQL_PASSWORD nao encontrado."; exit 1; }

DB_NETWORK=$(docker inspect portal-mysql-1 -f '{{range $k,$v := .NetworkSettings.Networks}}{{println $k}}{{end}}' 2>/dev/null | head -1)
[ -z "$DB_NETWORK" ] && { echo "ERRO: rede do portal-mysql-1 nao encontrada."; exit 1; }
echo "   Rede do MySQL: $DB_NETWORK"

mkdir -p "$(dirname "$SECRETS")"
touch "$SECRETS"
if ! grep -q '^PORTAL_LOJA_TOKEN=' "$SECRETS" 2>/dev/null; then
  echo "PORTAL_LOJA_TOKEN=$(openssl rand -hex 24)" >> "$SECRETS"
  echo "   Token portal<->loja GERADO (em $SECRETS)."
fi
PORTAL_LOJA_TOKEN=$(grep -E '^PORTAL_LOJA_TOKEN=' "$SECRETS" | head -1 | cut -d= -f2-)
FRP_TOKEN=$(grep -E '^FRP_TOKEN=' "$SECRETS" | head -1 | cut -d= -f2-)

echo ">> [2/5] Gravando .env do compose..."
{
  printf 'MYSQL_PASSWORD=%s\n' "$MYSQL_PASSWORD"
  printf 'ADMIN_SENHA=%s\n' "$ADMIN_SENHA"
  printf 'PORTAL_ADMIN_LOGIN=admin\n'
  printf 'DB_NETWORK=%s\n' "$DB_NETWORK"
  printf 'PORTAL_LOJA_TOKEN=%s\n' "$PORTAL_LOJA_TOKEN"
  printf 'FRP_TOKEN=%s\n' "$FRP_TOKEN"
} > "$APPDIR/.env"
chmod 600 "$APPDIR/.env"

echo ">> [3/5] Build e subida do container (1-2 min)..."
cd "$APPDIR"
docker compose up -d --build

echo ">> [4/5] Configurando o Caddy..."
printf '%s\n' 'portal.infosistemas.net.br {' '    encode gzip' '    reverse_proxy 127.0.0.1:8080' '}' > /etc/caddy/Caddyfile
systemctl reload caddy

echo ">> [5/5] Status:"
sleep 8
docker compose ps
echo "OK! Acesse: https://portal.infosistemas.net.br  (admin / sua senha)"
echo "Token da loja: sudo grep PORTAL_LOJA_TOKEN $SECRETS"
