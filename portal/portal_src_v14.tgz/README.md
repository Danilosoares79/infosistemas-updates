# InfoSistemas — Portal de Relatórios (multi-tenant)

Portal web central (ASP.NET Core 8 / Razor Pages) onde cada loja acessa seus
relatórios em tempo real. Roda no servidor AWS, atrás do Caddy (HTTPS), e lê os
dados de cada loja via túnel reverso (FRP).

## Arquitetura
- **Portal** (este projeto): login por CNPJ + senha (cliente vê só sua loja) e
  painel admin (vê todas). Banco próprio em MySQL (`portal_relatorios`).
- **API read-only na loja**: expõe os relatórios (reaproveita o RelatorioManager).
- **Agente de túnel (frpc)**: cada loja disca para o broker `:7000`, identificada
  pelo CNPJ; o portal alcança a API da loja em tempo real.

## Acesso
- Cliente: CNPJ da loja + usuário + senha.
- Admin: apenas usuário + senha (CNPJ ignorado).

## Variáveis de ambiente
- `PORTAL_DB` — connection string MySQL.
- `PORTAL_ADMIN_LOGIN` (padrão `admin`).
- `PORTAL_ADMIN_SENHA` — senha do admin no primeiro boot (seed).

## Deploy
Ver `deploy_portal.sh`: extrai o código no servidor, sobe via Docker na mesma
rede do MySQL e configura o Caddy (`portal.infosistemas.net.br`).

## Status
- [x] Login multi-tenant (CNPJ+senha) + cookie auth
- [x] Painel admin: cadastro de lojas e usuários
- [x] Catálogo de relatórios (vitrine)
- [ ] API read-only na loja + túnel frpc
- [ ] Dados reais nos relatórios + exportar PDF/Excel
