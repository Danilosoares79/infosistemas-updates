using InfoSistemas.Portal.Models;

namespace InfoSistemas.Portal.Services;

/// <summary>
/// Catálogo dos relatórios oferecidos no portal. Espelha o RelatorioManager do sistema.
/// Por enquanto é estático (vitrine). Quando o túnel da loja estiver ativo,
/// cada item chamará a API read-only da loja correspondente.
/// </summary>
public static class ReportCatalog
{
    public static readonly IReadOnlyList<RelatorioInfo> Todos = new List<RelatorioInfo>
    {
        new("vendas_periodo",   "Vendas por Período",        "Total de vendas, ticket médio e formas de pagamento.", "Vendas"),
        new("vendas_produto",   "Vendas por Produto",        "Ranking de produtos vendidos no período.",             "Vendas"),
        new("vendas_grupo",     "Vendas por Grupo",          "Faturamento agrupado por grupo de produtos.",          "Vendas"),
        new("vendas_garcom",    "Vendas por Garçom",         "Desempenho por garçom, com filtro por hora.",          "Vendas"),
        new("caixa",            "Caixa (Abertura/Fechamento)","Movimento de caixa, sangrias, suprimentos e diferenças.","Caixa"),
        new("penduras",         "Penduras / Fiado",          "Penduras em aberto e quitadas, por cliente.",          "Financeiro"),
        new("comandas_mesas",   "Comandas / Mesas (Completo)","Detalhe de comandas e mesas com itens.",               "Operação"),
        new("cartoes",          "Cartões de Consumo",        "Movimento de cartões, recargas e consumações.",        "Operação"),
        new("estoque",          "Posição de Estoque",        "Saldo atual, custo e curva de produtos.",              "Estoque"),
        new("contas_pagar",     "Contas a Pagar",            "Títulos a pagar por fornecedor e vencimento.",         "Financeiro"),
    };
}
