using System.Security.Claims;

namespace InfoSistemas.Portal.Services;

/// <summary>
/// [v7] Controle de acesso por usuário. A claim "perms" carrega o campo
/// usuario.permissoes: VAZIO = acesso total; senão só os tokens listados
/// (PAINEL, DASH, XMLSAIDA, REL:&lt;Id&gt;) são permitidos.
/// Ex.: contador da loja só com exportação de XML → permissoes = "XMLSAIDA".
/// Obs.: alterações de permissão valem no PRÓXIMO login do usuário.
/// </summary>
public static class Permissao
{
    public const string Painel     = "PAINEL";
    public const string Dashboards = "DASH";
    public const string XmlSaida   = "XMLSAIDA";

    /// <summary>true = usuário tem restrições configuradas (não é acesso total).</summary>
    public static bool Restrito(ClaimsPrincipal u) =>
        !u.HasClaim("is_admin", "true") &&
        !string.IsNullOrWhiteSpace(u.FindFirst("perms")?.Value);

    public static bool Tem(ClaimsPrincipal u, string token)
    {
        if (u.HasClaim("is_admin", "true")) return true;
        var p = u.FindFirst("perms")?.Value;
        if (string.IsNullOrWhiteSpace(p)) return true;   // acesso total
        return p.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Contains(token, StringComparer.OrdinalIgnoreCase);
    }

    public static bool TemRelatorio(ClaimsPrincipal u, string relatorioId) =>
        Tem(u, "REL:" + relatorioId);
}
