using System.Text;
using System.Text.Json;

namespace InfoSistemas.Portal.Services;

/// <summary>
/// Cliente HTTP que fala com a API read-only de uma loja, alcançada pelo túnel
/// reverso (frpc) em 127.0.0.1:{tunnelPort}. Autentica com o header X-Portal-Token.
/// </summary>
public class LojaApiClient
{
    private readonly HttpClient _http;
    private readonly string _token;
    private readonly string _host;
    private readonly ILogger<LojaApiClient> _log;

    public LojaApiClient(HttpClient http, IConfiguration cfg, ILogger<LojaApiClient> log)
    {
        _http = http;
        _log = log;
        _token = Environment.GetEnvironmentVariable("PORTAL_LOJA_TOKEN")
                 ?? cfg["Portal:LojaToken"] ?? "";
        // Host onde o frps expoe as portas remotas dos tuneis. Em producao o frps
        // roda em outro container (mesma rede docker), entao NAO eh 127.0.0.1: por
        // padrao usamos o nome do servico "portal-frps-1". Override por FRP_HOST.
        _host = Environment.GetEnvironmentVariable("FRP_HOST")
                ?? cfg["Portal:FrpHost"] ?? "portal-frps-1";
        _http.Timeout = TimeSpan.FromSeconds(20);
    }

    private static readonly JsonSerializerOptions J = new() { PropertyNameCaseInsensitive = true };

    /// <summary>GET genérico que devolve o corpo JSON bruto da API da loja (null se offline/erro).</summary>
    public async Task<string?> GetRawAsync(int porta, string caminho)
    {
        try
        {
            using var resp = await _http.SendAsync(Req(HttpMethod.Get, porta, caminho));
            if (!resp.IsSuccessStatusCode) return null;
            return await resp.Content.ReadAsStringAsync();
        }
        catch (Exception ex) { _log.LogWarning("GetRawAsync {c} falhou (porta {p}): {m}", caminho, porta, ex.Message); return null; }
    }

    private HttpRequestMessage Req(HttpMethod m, int porta, string caminho)
    {
        var r = new HttpRequestMessage(m, $"http://{_host}:{porta}{caminho}");
        r.Headers.Add("X-Portal-Token", _token);
        return r;
    }

    /// <summary>Verifica conexão e retorna dados da empresa, ou null se offline/erro.</summary>
    public async Task<EmpresaInfo?> EmpresaAsync(int porta)
    {
        try
        {
            using var resp = await _http.SendAsync(Req(HttpMethod.Get, porta, "/api/relatorios/empresa"));
            if (!resp.IsSuccessStatusCode) return null;
            var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
            var e = doc.RootElement.GetProperty("empresa");
            var cod = 1;
            if (e.TryGetProperty("codigo", out var cd) && cd.ValueKind == JsonValueKind.Number)
                cod = cd.GetInt32();
            return new EmpresaInfo(
                cod,
                e.TryGetProperty("razao", out var r) ? r.GetString() ?? "" : "",
                e.TryGetProperty("cnpj", out var c) ? c.GetString() ?? "" : "");
        }
        catch (Exception ex) { _log.LogWarning("EmpresaAsync falhou (porta {p}): {m}", porta, ex.Message); return null; }
    }

    /// <summary>Catálogo de relatórios da loja. Lista vazia se offline.</summary>
    public async Task<List<CatalogoItem>> CatalogoAsync(int porta)
    {
        try
        {
            using var resp = await _http.SendAsync(Req(HttpMethod.Get, porta, "/api/relatorios/catalogo"));
            if (!resp.IsSuccessStatusCode) return new();
            var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
            var lista = new List<CatalogoItem>();
            foreach (var r in doc.RootElement.GetProperty("relatorios").EnumerateArray())
            {
                var pars = new List<ParamItem>();
                if (r.TryGetProperty("parametros", out var pe))
                    foreach (var p in pe.EnumerateArray())
                        pars.Add(new ParamItem(
                            p.GetProperty("nome").GetString() ?? "",
                            p.GetProperty("label").GetString() ?? "",
                            p.GetProperty("tipo").GetString() ?? "",
                            p.TryGetProperty("padrao", out var pad) ? pad.GetString() ?? "" : ""));
                var cols = new List<ColunaInfo>();
                if (r.TryGetProperty("colunas", out var ce))
                    foreach (var col in ce.EnumerateArray())
                        cols.Add(new ColunaInfo(
                            col.TryGetProperty("campo", out var cf) ? cf.GetString() ?? "" : "",
                            col.TryGetProperty("titulo", out var ct) ? ct.GetString() ?? "" : "",
                            col.TryGetProperty("direita", out var cd) && cd.ValueKind == JsonValueKind.True,
                            col.TryGetProperty("formato", out var cfm) ? cfm.GetString() ?? "" : ""));
                lista.Add(new CatalogoItem(
                    r.GetProperty("id").GetString() ?? "",
                    r.GetProperty("nome").GetString() ?? "",
                    r.GetProperty("categoria").GetString() ?? "",
                    r.TryGetProperty("descricao", out var d) ? d.GetString() ?? "" : "",
                    pars, cols));
            }
            return lista;
        }
        catch (Exception ex) { _log.LogWarning("CatalogoAsync falhou (porta {p}): {m}", porta, ex.Message); return new(); }
    }

    /// <summary>Executa um relatório e devolve colunas + linhas. null se offline/erro.</summary>
    public async Task<ExecResult?> ExecutarAsync(int porta, string id, int empresa, Dictionary<string, string> filtros)
    {
        try
        {
            var body = JsonSerializer.Serialize(new { id, empresa, parametros = filtros });
            var req = Req(HttpMethod.Post, porta, "/api/relatorios/executar");
            req.Content = new StringContent(body, Encoding.UTF8, "application/json");
            using var resp = await _http.SendAsync(req);
            var txt = await resp.Content.ReadAsStringAsync();
            if (!resp.IsSuccessStatusCode) { _log.LogWarning("Executar {id} HTTP {s}: {t}", id, (int)resp.StatusCode, txt); return null; }

            var doc = JsonDocument.Parse(txt);
            var root = doc.RootElement;
            var cols = root.GetProperty("colunas").EnumerateArray().Select(c => c.GetString() ?? "").ToList();
            var linhas = new List<Dictionary<string, string>>();
            foreach (var ln in root.GetProperty("linhas").EnumerateArray())
            {
                var dic = new Dictionary<string, string>();
                foreach (var col in cols)
                {
                    var val = ln.TryGetProperty(col, out var v) ? FormatJson(v) : "";
                    dic[col] = val;
                }
                linhas.Add(dic);
            }
            return new ExecResult(cols, linhas);
        }
        catch (Exception ex) { _log.LogWarning("ExecutarAsync {id} falhou (porta {p}): {m}", id, porta, ex.Message); return null; }
    }

    /// <summary>[v7.6.174] Resumo do período para a página "XML Saída" (contagens por situação).</summary>
    public async Task<XmlSaidaResumo?> XmlSaidaResumoAsync(int porta, int empresa, string de, string ate)
    {
        try
        {
            using var resp = await _http.SendAsync(Req(HttpMethod.Get, porta,
                $"/api/xmlsaida/resumo?empresa={empresa}&de={de}&ate={ate}"));
            if (!resp.IsSuccessStatusCode) return null;
            var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
            var r = doc.RootElement;
            int I(string n) => r.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt32() : 0;
            decimal D(string n) => r.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDecimal() : 0;
            return new XmlSaidaResumo(I("total"), I("comXml"), I("autorizadas"), I("canceladas"),
                                      I("denegadas"), I("pendentes"), D("valorAutorizadas"));
        }
        catch (Exception ex) { _log.LogWarning("XmlSaidaResumoAsync falhou (porta {p}): {m}", porta, ex.Message); return null; }
    }

    /// <summary>[v7.6.174] Baixa o ZIP (XMLs + relatórios) da loja. ResponseHeadersRead
    /// para o download de arquivos grandes não esbarrar no timeout de 20s.</summary>
    public async Task<(byte[] Dados, string Nome)?> XmlSaidaZipAsync(int porta, int empresa, string de, string ate)
    {
        try
        {
            var req = Req(HttpMethod.Get, porta, $"/api/xmlsaida/zip?empresa={empresa}&de={de}&ate={ate}");
            using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead);
            if (!resp.IsSuccessStatusCode)
            {
                _log.LogWarning("XmlSaidaZipAsync HTTP {s} (porta {p})", (int)resp.StatusCode, porta);
                return null;
            }
            var nome = resp.Content.Headers.ContentDisposition?.FileNameStar
                       ?? resp.Content.Headers.ContentDisposition?.FileName?.Trim('"')
                       ?? $"XML_Saida_{de}_a_{ate}.zip";
            var dados = await resp.Content.ReadAsByteArrayAsync();
            return (dados, nome);
        }
        catch (Exception ex) { _log.LogWarning("XmlSaidaZipAsync falhou (porta {p}): {m}", porta, ex.Message); return null; }
    }

    private static string FormatJson(JsonElement v) => v.ValueKind switch
    {
        JsonValueKind.Null => "",
        JsonValueKind.Number => v.GetRawText(),
        JsonValueKind.String => v.GetString() ?? "",
        JsonValueKind.True => "Sim",
        JsonValueKind.False => "Não",
        _ => v.GetRawText(),
    };
}

public record EmpresaInfo(int Codigo, string Razao, string Cnpj);
public record ParamItem(string Nome, string Label, string Tipo, string Padrao);
public record ColunaInfo(string Campo, string Titulo, bool Direita, string Formato);
public record CatalogoItem(string Id, string Nome, string Categoria, string Descricao, List<ParamItem> Parametros, List<ColunaInfo> Colunas);
public record ExecResult(List<string> Colunas, List<Dictionary<string, string>> Linhas);
public record XmlSaidaResumo(int Total, int ComXml, int Autorizadas, int Canceladas,
                             int Denegadas, int Pendentes, decimal ValorAutorizadas);
