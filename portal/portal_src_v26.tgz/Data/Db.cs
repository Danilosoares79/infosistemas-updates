using Dapper;
using InfoSistemas.Portal.Models;
using InfoSistemas.Portal.Services;
using MySqlConnector;

namespace InfoSistemas.Portal.Data;

/// <summary>Acesso ao banco do portal (MySQL) via Dapper. Schema idempotente + seed do admin.</summary>
public class Db
{
    private readonly string _cs;
    private readonly ILogger<Db> _log;

    public Db(IConfiguration cfg, ILogger<Db> log)
    {
        _log = log;
        _cs = Environment.GetEnvironmentVariable("PORTAL_DB")
              ?? cfg.GetConnectionString("Portal")
              ?? "Server=mysql;Port=3306;Database=portal_relatorios;Uid=portal;Pwd=portal;";
    }

    public MySqlConnection Open() { var c = new MySqlConnection(_cs); c.Open(); return c; }

    public static string SoDigitos(string? s) => new string((s ?? "").Where(char.IsDigit).ToArray());

    public static string GerarChave() => Guid.NewGuid().ToString("N").Substring(0, 20).ToUpperInvariant();

    public async Task InicializarAsync()
    {
        for (var tentativa = 1; tentativa <= 30; tentativa++)
        {
            try { await using var c = new MySqlConnection(_cs); await c.OpenAsync(); break; }
            catch (Exception ex)
            {
                _log.LogWarning("Aguardando MySQL ({n}/30): {msg}", tentativa, ex.Message);
                await Task.Delay(2000);
                if (tentativa == 30) throw;
            }
        }

        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();

        await conn.ExecuteAsync(@"
CREATE TABLE IF NOT EXISTS cliente (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  cnpj          VARCHAR(18)  NOT NULL UNIQUE,
  razao_social  VARCHAR(200) NOT NULL,
  ativo         TINYINT(1)   NOT NULL DEFAULT 1,
  tunnel_host   VARCHAR(100) NOT NULL DEFAULT '127.0.0.1',
  tunnel_port   INT          NOT NULL DEFAULT 0,
  chave_ativacao VARCHAR(40) NULL,
  criado_em     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        await conn.ExecuteAsync(@"
CREATE TABLE IF NOT EXISTS usuario (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  fk_cliente  INT          NULL,
  login       VARCHAR(80)  NOT NULL,
  senha_hash  VARCHAR(255) NOT NULL,
  nome        VARCHAR(150) NOT NULL DEFAULT '',
  is_admin    TINYINT(1)   NOT NULL DEFAULT 0,
  ativo       TINYINT(1)   NOT NULL DEFAULT 1,
  criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_login_cliente (login, fk_cliente),
  CONSTRAINT fk_usuario_cliente FOREIGN KEY (fk_cliente) REFERENCES cliente(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Colunas adicionadas depois (idempotente)
        await GarantirColunaAsync(conn, "cliente", "chave_ativacao", "VARCHAR(40) NULL");
        // [v7] permissões por usuário (vazio = acesso total)
        await GarantirColunaAsync(conn, "usuario", "permissoes", "TEXT NULL");
        // [7.6.182] Backup na nuvem = recurso PAGO. Fonte da verdade no SERVIDOR:
        // só o suporte (MASTER) liga; o Portal recusa upload/list se estiver 0.
        await GarantirColunaAsync(conn, "cliente", "backup_nuvem_ativo", "TINYINT(1) NOT NULL DEFAULT 0");

        var qtdAdmin = await conn.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM usuario WHERE is_admin = 1");
        if (qtdAdmin == 0)
        {
            var adminLogin = Environment.GetEnvironmentVariable("PORTAL_ADMIN_LOGIN") ?? "admin";
            var adminSenha = Environment.GetEnvironmentVariable("PORTAL_ADMIN_SENHA");
            if (string.IsNullOrWhiteSpace(adminSenha))
            {
                adminSenha = "infosistemas";
                _log.LogWarning("PORTAL_ADMIN_SENHA nao definida - admin com senha padrao. TROQUE.");
            }
            await conn.ExecuteAsync(
                "INSERT INTO usuario (fk_cliente, login, senha_hash, nome, is_admin, ativo) " +
                "VALUES (NULL, @l, @h, 'Administrador', 1, 1)",
                new { l = adminLogin, h = PasswordHasher.Hash(adminSenha) });
        }
    }

    private static async Task GarantirColunaAsync(MySqlConnection conn, string tabela, string coluna, string ddl)
    {
        var existe = await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t AND COLUMN_NAME=@c",
            new { t = tabela, c = coluna });
        if (existe == 0) await conn.ExecuteAsync($"ALTER TABLE {tabela} ADD COLUMN {coluna} {ddl}");
    }

    // ===================== Autenticacao =====================
    public async Task<Usuario?> AutenticarAsync(string? cnpj, string login, string senha)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();

        var admin = await conn.QueryFirstOrDefaultAsync<Usuario>(@"
SELECT id Id, fk_cliente FkCliente, login Login, senha_hash SenhaHash, nome Nome,
       is_admin IsAdmin, ativo Ativo, criado_em CriadoEm
FROM usuario WHERE is_admin = 1 AND ativo = 1 AND login = @login", new { login });
        if (admin != null && PasswordHasher.Verify(senha, admin.SenhaHash)) return admin;

        var dig = SoDigitos(cnpj);
        if (dig.Length == 0) return null;

        var u = await conn.QueryFirstOrDefaultAsync<Usuario>(@"
SELECT u.id Id, u.fk_cliente FkCliente, u.login Login, u.senha_hash SenhaHash, u.nome Nome,
       u.is_admin IsAdmin, u.ativo Ativo, u.criado_em CriadoEm, u.permissoes Permissoes,
       c.cnpj ClienteCnpj, c.razao_social ClienteRazao
FROM usuario u JOIN cliente c ON c.id = u.fk_cliente
WHERE c.cnpj = @dig AND c.ativo = 1 AND u.ativo = 1 AND u.login = @login", new { dig, login });
        if (u != null && PasswordHasher.Verify(senha, u.SenhaHash)) return u;
        return null;
    }

    // ===================== Clientes =====================
    private const string SelCliente =
        "SELECT id Id, cnpj Cnpj, razao_social RazaoSocial, ativo Ativo, tunnel_host TunnelHost, " +
        "tunnel_port TunnelPort, chave_ativacao ChaveAtivacao, backup_nuvem_ativo BackupNuvemAtivo, criado_em CriadoEm FROM cliente ";

    // [7.6.182] Backup na nuvem (recurso pago) — liga/desliga e consulta por cliente.
    public async Task<bool> BackupNuvemAtivoAsync(string cnpjDigitos)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        var v = await conn.ExecuteScalarAsync<int?>(
            "SELECT backup_nuvem_ativo FROM cliente WHERE cnpj=@c AND ativo=1", new { c = cnpjDigitos });
        return v == 1;
    }

    public async Task DefinirBackupNuvemAsync(int clienteId, bool ativo)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("UPDATE cliente SET backup_nuvem_ativo=@a WHERE id=@id",
            new { a = ativo ? 1 : 0, id = clienteId });
    }

    public async Task<List<Cliente>> ListarClientesAsync()
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return (await conn.QueryAsync<Cliente>(SelCliente + "ORDER BY razao_social")).ToList();
    }

    public async Task<Cliente?> ObterClienteAsync(int id)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return await conn.QueryFirstOrDefaultAsync<Cliente>(SelCliente + "WHERE id=@id", new { id });
    }

    public async Task<Cliente?> ObterPorChaveAsync(string chave)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return await conn.QueryFirstOrDefaultAsync<Cliente>(SelCliente + "WHERE chave_ativacao=@chave AND ativo=1",
            new { chave });
    }

    /// <summary>Acha a loja pelo CNPJ/CPF (só dígitos) — usado pelo autoatendimento público.</summary>
    public async Task<Cliente?> ObterPorCnpjAsync(string cnpjDigitos)
    {
        if (string.IsNullOrWhiteSpace(cnpjDigitos)) return null;
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return await conn.QueryFirstOrDefaultAsync<Cliente>(SelCliente + "WHERE cnpj=@c AND ativo=1",
            new { c = cnpjDigitos });
    }

    public async Task<int> SalvarClienteAsync(Cliente c)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        var cnpj = SoDigitos(c.Cnpj);
        if (c.Id == 0)
        {
            if (c.TunnelPort <= 0)
            {
                var max = await conn.ExecuteScalarAsync<int?>("SELECT MAX(tunnel_port) FROM cliente");
                c.TunnelPort = Math.Max(16000, max ?? 16000) + 1;
            }
            if (string.IsNullOrWhiteSpace(c.ChaveAtivacao)) c.ChaveAtivacao = GerarChave();
            return await conn.ExecuteScalarAsync<int>(@"
INSERT INTO cliente (cnpj, razao_social, ativo, tunnel_host, tunnel_port, chave_ativacao)
VALUES (@cnpj, @RazaoSocial, @Ativo, @TunnelHost, @TunnelPort, @ChaveAtivacao);
SELECT LAST_INSERT_ID();",
                new { cnpj, c.RazaoSocial, c.Ativo, c.TunnelHost, c.TunnelPort, c.ChaveAtivacao });
        }
        await conn.ExecuteAsync(@"
UPDATE cliente SET cnpj=@cnpj, razao_social=@RazaoSocial, ativo=@Ativo,
       tunnel_host=@TunnelHost, tunnel_port=@TunnelPort WHERE id=@Id",
            new { cnpj, c.RazaoSocial, c.Ativo, c.TunnelHost, c.TunnelPort, c.Id });
        return c.Id;
    }

    // ===================== Usuarios =====================
    public async Task<List<Usuario>> ListarUsuariosAsync()
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return (await conn.QueryAsync<Usuario>(@"
SELECT u.id Id, u.fk_cliente FkCliente, u.login Login, u.nome Nome,
       u.is_admin IsAdmin, u.ativo Ativo, u.criado_em CriadoEm, u.permissoes Permissoes,
       c.cnpj ClienteCnpj, c.razao_social ClienteRazao
FROM usuario u LEFT JOIN cliente c ON c.id = u.fk_cliente
ORDER BY u.is_admin DESC, c.razao_social, u.login")).ToList();
    }

    public async Task CriarUsuarioAsync(int? fkCliente, string login, string senha, string nome, bool isAdmin,
        string? permissoes = null)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync(@"
INSERT INTO usuario (fk_cliente, login, senha_hash, nome, is_admin, ativo, permissoes)
VALUES (@fkCliente, @login, @hash, @nome, @isAdmin, 1, @permissoes)",
            new { fkCliente, login, hash = PasswordHasher.Hash(senha), nome, isAdmin,
                  permissoes = string.IsNullOrWhiteSpace(permissoes) ? null : permissoes });
    }

    /// <summary>[v7] Define as permissões do usuário (NULL/vazio = acesso total).</summary>
    public async Task AtualizarPermissoesAsync(int usuarioId, string? permissoes)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync(
            "UPDATE usuario SET permissoes=@p WHERE id=@id AND is_admin=0",
            new { p = string.IsNullOrWhiteSpace(permissoes) ? null : permissoes, id = usuarioId });
    }

    /// <summary>[v7] Permissões atuais direto do banco (para preservar REL: quando a loja está offline).</summary>
    public async Task<string?> ObterPermissoesAsync(int usuarioId)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        return await conn.ExecuteScalarAsync<string?>(
            "SELECT permissoes FROM usuario WHERE id=@id", new { id = usuarioId });
    }

    public async Task RedefinirSenhaAsync(int usuarioId, string novaSenha)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("UPDATE usuario SET senha_hash=@h WHERE id=@id",
            new { h = PasswordHasher.Hash(novaSenha), id = usuarioId });
    }

    public async Task DefinirAtivoUsuarioAsync(int usuarioId, bool ativo)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("UPDATE usuario SET ativo=@a WHERE id=@id AND is_admin=0",
            new { a = ativo, id = usuarioId });
    }

    public async Task AtualizarClienteAsync(int id, string razao, bool ativo, int porta)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync(
            "UPDATE cliente SET razao_social=@r, ativo=@a, tunnel_port=@p WHERE id=@id",
            new { r = (razao ?? "").Trim(), a = ativo, p = porta, id });
    }

    public async Task AtualizarUsuarioAsync(int id, string login, string nome)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync(
            "UPDATE usuario SET login=@l, nome=@n WHERE id=@id AND is_admin=0",
            new { l = (login ?? "").Trim(), n = (nome ?? "").Trim(), id });
    }

    public async Task AlterarSenhaAdminAsync(string novaSenha)
    {
        await using var conn = new MySqlConnection(_cs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("UPDATE usuario SET senha_hash=@h WHERE is_admin=1",
            new { h = PasswordHasher.Hash(novaSenha) });
    }
}
