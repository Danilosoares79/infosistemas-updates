using System.Text.RegularExpressions;

namespace InfoSistemas.Portal.Services;

// ============================================================
//  [7.6.182] BackupStore — armazenamento dos backups na nuvem.
//  Guarda os arquivos em disco (volume do container) por CNPJ e mantém
//  SEMPRE só os 2 mais recentes por cliente (rotação). Pasta base vem de
//  BACKUP_DIR (env) — por padrão /app/backups (montar como volume no compose).
// ============================================================
public class BackupStore
{
    private readonly string _baseDir;
    private const int MaxPorCliente = 2;
    private static readonly Regex RxNome = new(@"^[A-Za-z0-9._-]{1,80}$", RegexOptions.Compiled);

    public BackupStore(IConfiguration cfg)
    {
        _baseDir = Environment.GetEnvironmentVariable("BACKUP_DIR")
                   ?? cfg["BackupDir"]
                   ?? "/app/backups";
    }

    public sealed record ItemBackup(string Nome, long Tamanho, DateTime DataUtc);

    private static string Dig(string cnpj) => new(cnpj.Where(char.IsDigit).ToArray());

    private string PastaDe(string cnpj)
    {
        var d = Path.Combine(_baseDir, Dig(cnpj));
        Directory.CreateDirectory(d);
        return d;
    }

    /// <summary>Grava o backup recebido e aplica a rotação (mantém 2). Retorna nome+tamanho.</summary>
    public async Task<ItemBackup> SalvarAsync(string cnpj, string nomeArquivo, Stream conteudo)
    {
        if (!RxNome.IsMatch(nomeArquivo)) nomeArquivo = $"backup-{DateTime.UtcNow:yyyyMMdd-HHmmss}.fbk.gz";
        var pasta = PastaDe(cnpj);
        var destino = Path.Combine(pasta, nomeArquivo);
        await using (var fs = File.Create(destino))
            await conteudo.CopyToAsync(fs);

        Rotacionar(pasta);
        var fi = new FileInfo(destino);
        return new ItemBackup(fi.Name, fi.Length, fi.LastWriteTimeUtc);
    }

    /// <summary>Lista os backups do cliente (mais recentes primeiro), no máximo 2.</summary>
    public List<ItemBackup> Listar(string cnpj)
    {
        var pasta = PastaDe(cnpj);
        return new DirectoryInfo(pasta).GetFiles()
            .OrderByDescending(f => f.LastWriteTimeUtc)
            .Take(MaxPorCliente)
            .Select(f => new ItemBackup(f.Name, f.Length, f.LastWriteTimeUtc))
            .ToList();
    }

    /// <summary>Caminho físico de um backup, validando o nome (evita path traversal). Null se não existir.</summary>
    public string? CaminhoDownload(string cnpj, string nome)
    {
        if (!RxNome.IsMatch(nome)) return null;
        var caminho = Path.Combine(PastaDe(cnpj), nome);
        return File.Exists(caminho) ? caminho : null;
    }

    private static void Rotacionar(string pasta)
    {
        var antigos = new DirectoryInfo(pasta).GetFiles()
            .OrderByDescending(f => f.LastWriteTimeUtc)
            .Skip(MaxPorCliente)
            .ToList();
        foreach (var f in antigos)
            try { f.Delete(); } catch { }
    }
}
