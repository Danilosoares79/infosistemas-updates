using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.HttpOverrides;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSingleton<Db>();
builder.Services.AddSingleton<SyncStore>();   // [ETAPA 2] réplica por cliente
builder.Services.AddHttpClient<LojaApiClient>();
builder.Services.AddHttpClient(); // factory genérico p/ o proxy do autoatendimento

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.LoginPath = "/Login";
        o.LogoutPath = "/Logout";
        o.AccessDeniedPath = "/Login";
        o.ExpireTimeSpan = TimeSpan.FromHours(8);
        o.SlidingExpiration = true;
        o.Cookie.Name = "InfoPortal";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;
    });

builder.Services.AddAuthorization(o =>
{
    o.AddPolicy("AdminOnly", p => p.RequireClaim("is_admin", "true"));
});

// Atrás do Caddy (proxy HTTPS) — confia nos headers encaminhados.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.XForwardedFor
                       | Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.XForwardedProto;
    o.KnownNetworks.Clear();
    o.KnownProxies.Clear();
});

var app = builder.Build();

app.UseForwardedHeaders();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapRazorPages();

// Endpoint de ativacao (provisionamento) — o Retaguarda chama com a chave e recebe
// a config para se autoconectar. A propria chave e o segredo (anonimo).
app.MapPost("/api/prov/ativar", async (HttpContext ctx, Db db) =>
{
    string chave = "";
    try
    {
        using var doc = await System.Text.Json.JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("chave", out var k)) chave = (k.GetString() ?? "").Trim().ToUpperInvariant();
    }
    catch { }
    if (string.IsNullOrWhiteSpace(chave))
        return Results.BadRequest(new { ok = false, mensagem = "chave ausente" });

    var cli = await db.ObterPorChaveAsync(chave);
    if (cli == null)
        return Results.Json(new { ok = false, mensagem = "chave invalida" }, statusCode: 404);

    return Results.Ok(new
    {
        ok = true,
        cnpj = cli.Cnpj,
        nome = cli.RazaoSocial,
        serverAddr = Environment.GetEnvironmentVariable("FRP_SERVER") ?? "98.94.223.97",
        brokerPort = 7000,
        tunnelPort = cli.TunnelPort,
        frpToken = Environment.GetEnvironmentVariable("FRP_TOKEN") ?? "",
        portalToken = Environment.GetEnvironmentVariable("PORTAL_LOJA_TOKEN") ?? "",
        // [v11] token da sincronização de cadastros — o Retaguarda configura a
        // seção Sync do appsettings sozinho na ativação (Retaguarda Web).
        syncToken = Environment.GetEnvironmentVariable("SYNC_TOKEN") ?? ""
    });
});

// ════════════════════════════════════════════════════════════════════════
//  [ETAPA 2 — Retaguarda Web] SINCRONIZAÇÃO loja→nuvem
//  A loja empurra a carga inicial e as alterações (changelog) para a
//  réplica MySQL `sync_<cnpj>`. Autenticação dupla: header X-Sync-Token
//  (env SYNC_TOKEN) + cnpj/chave de ativação do cliente.
// ════════════════════════════════════════════════════════════════════════
bool SyncTokenOk(HttpContext ctx)
{
    var esperado = Environment.GetEnvironmentVariable("SYNC_TOKEN") ?? "";
    var recebido = ctx.Request.Headers["X-Sync-Token"].ToString();
    return esperado.Length > 0 && recebido.Length > 0 &&
           System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(
               System.Text.Encoding.UTF8.GetBytes(recebido),
               System.Text.Encoding.UTF8.GetBytes(esperado));
}

static List<SyncStore.ColunaSpec> LerColunas(System.Text.Json.JsonElement e)
{
    var cols = new List<SyncStore.ColunaSpec>();
    if (e.ValueKind != System.Text.Json.JsonValueKind.Array) return cols;
    foreach (var c in e.EnumerateArray())
        cols.Add(new SyncStore.ColunaSpec(
            (c.GetProperty("nome").GetString() ?? "").Trim().ToUpperInvariant(),
            (c.GetProperty("tipo").GetString() ?? "").Trim().ToUpperInvariant()));
    return cols;
}

static Dictionary<string, string?> LerLinha(System.Text.Json.JsonElement e)
{
    var d = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
    foreach (var p in e.EnumerateObject())
        d[p.Name.ToUpperInvariant()] = p.Value.ValueKind == System.Text.Json.JsonValueKind.Null
            ? null : p.Value.GetString();
    return d;
}

app.MapPost("/api/sync/carga", async (HttpContext ctx, SyncStore store) =>
{
    if (!SyncTokenOk(ctx)) return Results.Unauthorized();
    using var doc = await System.Text.Json.JsonDocument.ParseAsync(ctx.Request.Body);
    var r = doc.RootElement;
    var cnpj  = r.GetProperty("cnpj").GetString() ?? "";
    var chave = r.GetProperty("chave").GetString() ?? "";
    if (!await store.AutenticarLojaAsync(cnpj, chave))
        return Results.Json(new { ok = false, mensagem = "loja não autorizada" }, statusCode: 403);
    try
    {
        var tabela = (r.GetProperty("tabela").GetString() ?? "").Trim().ToUpperInvariant();
        var pk     = (r.GetProperty("pk").GetString() ?? "").Trim().ToUpperInvariant();
        var reset  = r.TryGetProperty("reset", out var rs) && rs.ValueKind == System.Text.Json.JsonValueKind.True;
        var cols   = LerColunas(r.GetProperty("colunas"));
        var linhas = new List<Dictionary<string, string?>>();
        if (r.TryGetProperty("linhas", out var ls) && ls.ValueKind == System.Text.Json.JsonValueKind.Array)
            foreach (var l in ls.EnumerateArray()) linhas.Add(LerLinha(l));

        await store.GarantirSchemaAsync(cnpj);
        await store.GarantirTabelaAsync(cnpj, tabela, pk, cols, reset);
        await store.UpsertAsync(cnpj, tabela, pk, linhas);
        var versao = r.TryGetProperty("versaoLoja", out var vl) ? vl.GetString() : null;
        await store.AtualizarStatusAsync(cnpj, null, cargaFeita: true, versao);
        return Results.Ok(new { ok = true, recebidas = linhas.Count });
    }
    catch (Exception ex)
    {
        return Results.Json(new { ok = false, mensagem = ex.Message }, statusCode: 500);
    }
});

app.MapPost("/api/sync/subida", async (HttpContext ctx, SyncStore store) =>
{
    if (!SyncTokenOk(ctx)) return Results.Unauthorized();
    using var doc = await System.Text.Json.JsonDocument.ParseAsync(ctx.Request.Body);
    var r = doc.RootElement;
    var cnpj  = r.GetProperty("cnpj").GetString() ?? "";
    var chave = r.GetProperty("chave").GetString() ?? "";
    if (!await store.AutenticarLojaAsync(cnpj, chave))
        return Results.Json(new { ok = false, mensagem = "loja não autorizada" }, statusCode: 403);
    try
    {
        var seqLote = r.GetProperty("seqLote").GetInt64();
        await store.GarantirSchemaAsync(cnpj);
        foreach (var item in r.GetProperty("itens").EnumerateArray())
        {
            var tabela = (item.GetProperty("tabela").GetString() ?? "").Trim().ToUpperInvariant();
            var pkVal  = item.GetProperty("pk").GetString() ?? "";
            var op     = (item.GetProperty("op").GetString() ?? "U").Trim().ToUpperInvariant();
            var cols   = LerColunas(item.GetProperty("colunas"));
            var pkCol  = cols.Count > 0 ? cols[0].Nome : "CODIGO"; // 1ª coluna = PK (CODIGO)
            if (op == "D")
            {
                await store.DeleteAsync(cnpj, tabela, pkCol, pkVal);
            }
            else if (item.TryGetProperty("linha", out var ln) && ln.ValueKind == System.Text.Json.JsonValueKind.Object)
            {
                // tabela pode ainda não existir (loja nova sem carga? cria pela estrutura)
                await store.GarantirTabelaAsync(cnpj, tabela, pkCol, cols, reset: false);
                await store.UpsertAsync(cnpj, tabela, pkCol, [LerLinha(ln)]);
            }
        }
        await store.AtualizarStatusAsync(cnpj, seqLote, null, null);
        return Results.Ok(new { ok = true, seqConfirmada = seqLote });
    }
    catch (Exception ex)
    {
        return Results.Json(new { ok = false, mensagem = ex.Message }, statusCode: 500);
    }
});

// ════════════════════════════════════════════════════════════════════════
//  AUTOATENDIMENTO PÚBLICO (anônimo) — o cliente lê o QR da mesa pelo próprio
//  celular (qualquer rede). O Portal serve o cardápio mobile e repassa as
//  chamadas para a API da loja pelo túnel frp. Escopo restrito: só as rotas
//  de cardápio/pedido (token da mesa). O resto da API da loja NÃO é exposto.
// ════════════════════════════════════════════════════════════════════════
string FrpHostAuto() => Environment.GetEnvironmentVariable("FRP_HOST") ?? "portal-frps-1";

async Task<int> PortaLojaAuto(Db db, string loja)
{
    var cli = await db.ObterPorCnpjAsync(Db.SoDigitos(loja));
    return cli?.TunnelPort ?? 0;
}

async Task<IResult> AutoProxy(IHttpClientFactory hf, Db db, string loja, string apiPath, HttpMethod metodo, string? body)
{
    var porta = await PortaLojaAuto(db, loja);
    if (porta <= 0) return Results.Json(new { ok = false, mensagem = "Loja não encontrada." }, statusCode: 404);
    try
    {
        var c = hf.CreateClient();
        c.Timeout = TimeSpan.FromSeconds(20);
        using var req = new HttpRequestMessage(metodo, $"http://{FrpHostAuto()}:{porta}{apiPath}");
        if (body != null) req.Content = new StringContent(body, System.Text.Encoding.UTF8, "application/json");
        using var resp = await c.SendAsync(req);
        var txt = await resp.Content.ReadAsStringAsync();
        return Results.Content(txt, "application/json", System.Text.Encoding.UTF8, (int)resp.StatusCode);
    }
    catch { return Results.Json(new { ok = false, mensagem = "Loja offline no momento." }, statusCode: 502); }
}

app.MapGet("/auto/{loja}/cardapio/{token}", (IHttpClientFactory hf, Db db, string loja, string token) =>
    AutoProxy(hf, db, loja, $"/api/cardapio/{token}", HttpMethod.Get, null));
app.MapGet("/auto/{loja}/modo/{token}", (IHttpClientFactory hf, Db db, string loja, string token) =>
    AutoProxy(hf, db, loja, $"/api/modo/{token}", HttpMethod.Get, null));
app.MapGet("/auto/{loja}/conta/{token}", (IHttpClientFactory hf, Db db, string loja, string token) =>
    AutoProxy(hf, db, loja, $"/api/mesa/{token}/conta", HttpMethod.Get, null));
app.MapPost("/auto/{loja}/pedido/{token}", async (IHttpClientFactory hf, Db db, HttpContext ctx, string loja, string token) =>
{
    using var sr = new StreamReader(ctx.Request.Body);
    var b = await sr.ReadToEndAsync();
    return await AutoProxy(hf, db, loja, $"/api/mesa/{token}/pedido", HttpMethod.Post, string.IsNullOrWhiteSpace(b) ? "{}" : b);
});
app.MapPost("/auto/{loja}/confirmar/{token}", (IHttpClientFactory hf, Db db, string loja, string token) =>
    AutoProxy(hf, db, loja, $"/api/mesa/{token}/confirmar", HttpMethod.Post, "{}"));
app.MapPost("/auto/{loja}/pedirconta/{token}", (IHttpClientFactory hf, Db db, string loja, string token) =>
    AutoProxy(hf, db, loja, $"/api/mesa/{token}/pedirconta", HttpMethod.Post, "{}"));

// Página do cardápio mobile (HTML) — aberta pelo QR da mesa.
app.MapGet("/menu/{loja}/{token}", (string loja, string token) =>
    Results.Content(InfoSistemas.Portal.MenuPage.Html(loja, token), "text/html; charset=utf-8"));

// ════════════════════════════════════════════════════════════════════════
//  DELIVERY ONLINE PÚBLICO (anônimo) — o cliente abre o link da loja pelo
//  próprio celular (qualquer rede), cadastra-se e faz o pedido. O Portal
//  serve a página mobile e repassa as chamadas à API da loja pelo túnel.
//  Escopo restrito: só as rotas de delivery. Pedido cai como 'AG' para
//  aprovação no Frente de Caixa.
// ════════════════════════════════════════════════════════════════════════
app.MapGet("/entrega/{loja}/cardapio", (IHttpClientFactory hf, Db db, string loja) =>
    AutoProxy(hf, db, loja, "/api/delivery/cardapio", HttpMethod.Get, null));
app.MapGet("/entrega/{loja}/status", (IHttpClientFactory hf, Db db, string loja) =>
    AutoProxy(hf, db, loja, "/api/delivery/status", HttpMethod.Get, null));
app.MapPost("/entrega/{loja}/pedido", async (IHttpClientFactory hf, Db db, HttpContext ctx, string loja) =>
{
    using var sr = new StreamReader(ctx.Request.Body);
    var b = await sr.ReadToEndAsync();
    return await AutoProxy(hf, db, loja, "/api/delivery/pedido", HttpMethod.Post, string.IsNullOrWhiteSpace(b) ? "{}" : b);
});

// Página do delivery online (HTML) — link fixo por loja.
app.MapGet("/delivery/{loja}", (string loja) =>
    Results.Content(InfoSistemas.Portal.DeliveryPage.Html(loja), "text/html; charset=utf-8"));

// Inicializa o banco (schema + seed admin) no startup.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<Db>();
    await db.InicializarAsync();
}

app.Run();
