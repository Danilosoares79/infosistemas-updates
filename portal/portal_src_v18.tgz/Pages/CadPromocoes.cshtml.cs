using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>[ETAPA 3 — Retaguarda Web] Cadastros → Promoções (somente leitura, da réplica).</summary>
[Authorize]
public class CadPromocoesModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public CadPromocoesModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public string Loja { get; private set; } = "";
    [BindProperty(SupportsGet = true)] public string? F { get; set; }
    public List<SyncStore.PromocaoReplica> Itens { get; private set; } = new();
    public SyncStore.ReplicaStatus? Status { get; private set; }
    public string? Aviso { get; private set; }

    // [ETAPA 5] edição
    public bool PodeEditar => Permissao.Tem(User, "ADM:PROMOCOES");
    public Dictionary<int, List<(int Codigo, int FkProduto, string Produto, decimal Preco)>> ItensPromo { get; } = new();
    public List<(int Codigo, string Descricao)> Produtos { get; private set; } = new();
    [TempData] public string? Msg { get; set; }
    [TempData] public string? MsgErro { get; set; }

    private async Task<string?> CnpjAsync()
    {
        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        return clienteId > 0 ? (await _db.ObterClienteAsync(clienteId))?.Cnpj : null;
    }

    // [v15] aceita "25,00" (BR), "25.00" e "1.250,50" — ponto SÓ é milhar se houver vírgula
    private static string? Num(string? v)
    {
        if (string.IsNullOrWhiteSpace(v)) return null;
        v = v.Trim();
        if (v.Contains(',')) v = v.Replace(".", "").Replace(',', '.');
        return decimal.Parse(v, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture)
            .ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>[ETAPA 5] Nova promoção ou edição do cabeçalho (U se codigo>0, senão I).</summary>
    public async Task<IActionResult> OnPostSalvarPromoAsync(int codigo, string descricao,
        string dataInicial, string dataFinal, string? ativo)
    {
        if (!PodeEditar) { MsgErro = "Sem permissão para promoções."; return RedirectToPage(); }
        var cnpj = await CnpjAsync(); if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        if (string.IsNullOrWhiteSpace(descricao) || !DateTime.TryParse(dataInicial, out var d1) ||
            !DateTime.TryParse(dataFinal, out var d2) || d2 < d1)
        { MsgErro = "Preencha descrição e um período válido (fim ≥ início)."; return RedirectToPage(); }
        var dados = new Dictionary<string, string?>
        {
            ["EMPRESA"] = "1",
            ["DESCRICAO"] = descricao.Trim(),
            ["DATA_INICIAL"] = d1.ToString("yyyy-MM-dd"),
            ["DATA_FINAL"] = d2.ToString("yyyy-MM-dd"),
            ["ATIVO"] = ativo == "S" ? "S" : "N",
        };
        await _sync.EnfileirarAsync(cnpj, "PROMOCAO", codigo > 0 ? codigo.ToString() : null,
            codigo > 0 ? "U" : "I", dados, User.Identity?.Name ?? "portal");
        Msg = codigo > 0 ? "Alteração da promoção enviada — aplica na loja em ~1 minuto."
                         : "Promoção nova enviada — a loja cria o código em ~1 minuto; depois adicione os produtos.";
        return RedirectToPage();
    }

    /// <summary>[ETAPA 5] Adiciona produto à promoção (preço promocional).</summary>
    public async Task<IActionResult> OnPostAddItemAsync(int promo, int produto, string preco)
    {
        if (!PodeEditar) { MsgErro = "Sem permissão."; return RedirectToPage(); }
        var cnpj = await CnpjAsync(); if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        var p = Num(preco);
        if (promo <= 0 || produto <= 0 || p is null or "0")
        { MsgErro = "Escolha o produto e um preço promocional maior que zero."; return RedirectToPage(); }
        await _sync.EnfileirarAsync(cnpj, "PROMOCAO_ITEM", null, "I", new Dictionary<string, string?>
        {
            ["FK_PROMOCAO"] = promo.ToString(), ["FK_PRODUTO"] = produto.ToString(), ["PRECO_PROMOCIONAL"] = p,
        }, User.Identity?.Name ?? "portal");
        Msg = "Produto adicionado à promoção — aplica na loja em ~1 minuto.";
        return RedirectToPage();
    }

    /// <summary>[ETAPA 5] Remove produto da promoção.</summary>
    public async Task<IActionResult> OnPostDelItemAsync(int item)
    {
        if (!PodeEditar) { MsgErro = "Sem permissão."; return RedirectToPage(); }
        var cnpj = await CnpjAsync(); if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        await _sync.EnfileirarAsync(cnpj, "PROMOCAO_ITEM", item.ToString(), "D",
            new Dictionary<string, string?>(), User.Identity?.Name ?? "portal");
        Msg = "Remoção enviada — aplica na loja em ~1 minuto.";
        return RedirectToPage();
    }

    public static string Situacao(SyncStore.PromocaoReplica p)
    {
        if (p.Ativo == "N") return "Inativa";
        var hoje = DateTime.Today;
        if (p.DataFinal.Date < hoje) return "Encerrada";
        if (p.DataInicial.Date > hoje) return "Futura";
        return "VIGENTE";
    }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true")) return RedirectToPage("/Admin/Index");
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null) { Aviso = "Loja não encontrada."; return Page(); }

        Status = await _sync.StatusTipadoAsync(cliente.Cnpj);
        if (Status == null || Status.CargaFeita != "S")
        {
            Aviso = "A sincronização desta loja ainda não foi ativada. " +
                    "Os cadastros aparecem aqui depois da primeira carga (fale com o suporte).";
            return Page();
        }

        Itens = await _sync.ListarPromocoesAsync(cliente.Cnpj, F);
        if (PodeEditar)
        {
            foreach (var pr in Itens)
                ItensPromo[pr.Codigo] = await _sync.ListarItensPromocaoAsync(cliente.Cnpj, pr.Codigo);
            var (_, prods) = await _sync.ListarProdutosAsync(cliente.Cnpj, null, 1, 500);
            Produtos = prods.Where(p => p.Ativo != "N").Select(p => (p.Codigo, p.Descricao)).ToList();
        }
        return Page();
    }
}
