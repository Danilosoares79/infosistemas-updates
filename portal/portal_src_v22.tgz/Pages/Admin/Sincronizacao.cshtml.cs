using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Models;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages.Admin;

/// <summary>[ETAPA 3 — Retaguarda Web] Status de sincronização de TODAS as lojas.</summary>
[Authorize(Policy = "AdminOnly")]
public class SincronizacaoModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public SincronizacaoModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public sealed record Linha(Cliente Cliente, SyncStore.ReplicaStatus? Status,
        bool Pausada, int ErrosAntigos);
    public List<Linha> Linhas { get; private set; } = new();
    [Microsoft.AspNetCore.Mvc.TempData] public string? Msg { get; set; }

    public async Task OnGetAsync()
    {
        foreach (var c in await _db.ListarClientesAsync())
        {
            var (pausada, errosAntigos) = await _sync.PausaEAlertaAsync(c.Cnpj);
            Linhas.Add(new Linha(c, await _sync.StatusTipadoAsync(c.Cnpj), pausada, errosAntigos));
        }
    }

    /// <summary>[v20] Pausar/retomar a DESCIDA de uma loja (contingência: a fila acumula).</summary>
    public async Task<Microsoft.AspNetCore.Mvc.IActionResult> OnPostPausaAsync(string cnpj, string acao)
    {
        await _sync.DefinirPausaAsync(cnpj, acao == "pausar");
        Msg = acao == "pausar"
            ? $"Descida da loja {cnpj} PAUSADA — as edições do portal ficam na fila até retomar."
            : $"Descida da loja {cnpj} retomada.";
        return RedirectToPage();
    }

    public static string Farol(SyncStore.ReplicaStatus? s)
    {
        if (s == null || s.CargaFeita != "S") return "—";
        if (s.UltimaSync == null) return "—";
        var idade = DateTime.Now - s.UltimaSync.Value;
        return idade.TotalMinutes <= 10 ? "🟢" : idade.TotalHours <= 24 ? "🟡" : "🔴";
    }
}
