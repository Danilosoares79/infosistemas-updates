using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>
/// [FASE 2 — Retaguarda Web] Cadastros auxiliares (Grupos, Couvert, Taxa de
/// Serviço, Bairros) — UMA página genérica: lista da réplica + edição/novo via
/// fila de descida (requer loja na 7.6.178+). Campos fiscais NÃO aparecem aqui.
/// Permissão: ADM:PRODUTOS (dono da loja).
/// </summary>
[Authorize]
public class CadAuxModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public CadAuxModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public sealed record Campo(string Nome, string Label, string Tipo); // txt | dec | int | chk
    public sealed record Cfg(string Tabela, string Titulo, Campo[] Campos);

    public static readonly Dictionary<string, Cfg> Cfgs = new(StringComparer.OrdinalIgnoreCase)
    {
        ["grupos"] = new("GRUPO", "Grupos de Produtos",
            [new("DESCRICAO", "Descrição", "txt"), new("ORDEM", "Ordem", "int"), new("ATIVO", "Ativo", "chk")]),
        ["couvert"] = new("COUVERT", "Couvert",
            [new("DESCRICAO", "Descrição", "txt"), new("VALOR_PESSOA", "Valor por pessoa", "dec"),
             new("PADRAO", "Padrão", "chk"), new("ATIVO", "Ativo", "chk")]),
        ["taxaservico"] = new("TAXA_SERVICO", "Taxa de Serviço",
            [new("DESCRICAO", "Descrição", "txt"), new("PERCENTUAL", "Percentual (%)", "dec"),
             new("PADRAO", "Padrão", "chk"), new("ATIVO", "Ativo", "chk")]),
        ["bairros"] = new("BAIRRO", "Bairros / Taxa de Entrega",
            [new("NOME", "Nome", "txt"), new("CIDADE", "Cidade", "txt"), new("UF", "UF", "txt"),
             new("TAXA_ENTREGA", "Taxa de entrega", "dec"), new("TEMPO_MEDIO", "Tempo médio (min)", "int"),
             new("ATIVO", "Ativo", "chk")]),
    };

    public string Loja { get; private set; } = "";
    public Cfg? C { get; private set; }
    public string Tab { get; private set; } = "";
    public List<IDictionary<string, object>> Itens { get; private set; } = new();
    public SyncStore.ReplicaStatus? Status { get; private set; }
    public bool PodeEditar => Permissao.Tem(User, "ADM:PRODUTOS");
    public string? Aviso { get; private set; }
    [TempData] public string? Msg { get; set; }
    [TempData] public string? MsgErro { get; set; }

    private async Task<string?> CnpjAsync()
    {
        var id = int.TryParse(User.FindFirst("cliente_id")?.Value, out var i) ? i : 0;
        return id > 0 ? (await _db.ObterClienteAsync(id))?.Cnpj : null;
    }

    private static string? Num(string? v)
    {
        if (string.IsNullOrWhiteSpace(v)) return null;
        v = v.Trim();
        if (v.Contains(',')) v = v.Replace(".", "").Replace(',', '.');
        return decimal.Parse(v, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture)
            .ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    public async Task<IActionResult> OnGetAsync(string tab)
    {
        if (User.HasClaim("is_admin", "true")) return RedirectToPage("/Admin/Index");
        Tab = tab;
        if (!Cfgs.TryGetValue(tab, out var cfg)) return RedirectToPage("/CadProdutos");
        C = cfg;
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";
        var cnpj = await CnpjAsync();
        if (cnpj == null) { Aviso = "Loja não encontrada."; return Page(); }
        Status = await _sync.StatusTipadoAsync(cnpj);
        if (Status == null || Status.CargaFeita != "S")
        { Aviso = "A sincronização desta loja ainda não foi ativada."; return Page(); }
        Itens = await _sync.ListarAuxAsync(cnpj, cfg.Tabela);
        return Page();
    }

    private Dictionary<string, string?> LerForm(Cfg cfg)
    {
        var d = new Dictionary<string, string?>();
        foreach (var c2 in cfg.Campos)
        {
            var v = Request.Form["c_" + c2.Nome].ToString();
            d[c2.Nome] = c2.Tipo switch
            {
                "chk" => string.IsNullOrEmpty(v) ? "N" : "S",
                "dec" => Num(v),
                "int" => string.IsNullOrWhiteSpace(v) ? null : int.Parse(v).ToString(),
                _ => string.IsNullOrWhiteSpace(v) ? null : v.Trim(),
            };
        }
        return d;
    }

    public async Task<IActionResult> OnPostSalvarAsync(string tab, int codigo)
    {
        if (!PodeEditar || !Cfgs.TryGetValue(tab, out var cfg))
        { MsgErro = "Sem permissão."; return RedirectToPage(new { tab }); }
        var cnpj = await CnpjAsync();
        if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(new { tab }); }
        try
        {
            await _sync.EnfileirarAsync(cnpj, cfg.Tabela, codigo.ToString(), "U",
                LerForm(cfg), User.Identity?.Name ?? "portal");
            Msg = "Alteração enviada — a loja aplica em ~1 minuto (requer loja na versão 7.6.178+).";
        }
        catch (Exception ex) { MsgErro = "Não foi possível enviar: " + ex.Message; }
        return RedirectToPage(new { tab });
    }

    public async Task<IActionResult> OnPostNovoAsync(string tab)
    {
        if (!PodeEditar || !Cfgs.TryGetValue(tab, out var cfg))
        { MsgErro = "Sem permissão."; return RedirectToPage(new { tab }); }
        var cnpj = await CnpjAsync();
        if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(new { tab }); }
        try
        {
            var d = LerForm(cfg);
            d["EMPRESA"] = "1";
            await _sync.EnfileirarAsync(cnpj, cfg.Tabela, null, "I", d, User.Identity?.Name ?? "portal");
            Msg = "Registro novo enviado — a loja cria o código em ~1 minuto (requer loja na 7.6.178+).";
        }
        catch (Exception ex) { MsgErro = "Não foi possível enviar: " + ex.Message; }
        return RedirectToPage(new { tab });
    }

    public string Val(IDictionary<string, object> row, string campo) =>
        row.TryGetValue(campo, out var v) && v != null ? v.ToString() ?? "" : "";
}
