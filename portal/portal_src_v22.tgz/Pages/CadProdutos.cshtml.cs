using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>
/// [ETAPA 3 — Retaguarda Web] Cadastros → Produtos (SOMENTE LEITURA nesta fase).
/// Lê a RÉPLICA `sync_&lt;cnpj&gt;` — funciona mesmo com a loja fechada/offline,
/// mostrando "dados atualizados em …". A edição chega na Etapa 5.
/// </summary>
[Authorize]
public class CadProdutosModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public CadProdutosModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public string Loja { get; private set; } = "";
    [BindProperty(SupportsGet = true)] public string? F { get; set; }
    [BindProperty(SupportsGet = true)] public int Pg { get; set; } = 1;
    public int Total { get; private set; }
    public int Paginas => Math.Max(1, (int)Math.Ceiling(Total / 50.0));
    public List<SyncStore.ProdutoReplica> Itens { get; private set; } = new();
    public SyncStore.ReplicaStatus? Status { get; private set; }
    public string? Aviso { get; private set; }

    // [ETAPA 5] edição
    public bool PodeEditar => Permissao.Tem(User, "ADM:PRODUTOS");
    public List<(int Codigo, string Descricao)> Grupos { get; private set; } = new();
    public (int Pendentes, int Erros) Fila { get; private set; }
    public List<SyncStore.FilaItem> FilaUltimas { get; private set; } = new();
    [TempData] public string? Msg { get; set; }
    [TempData] public string? MsgErro { get; set; }

    private async Task<string?> CnpjAsync()
    {
        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        return clienteId > 0 ? (await _db.ObterClienteAsync(clienteId))?.Cnpj : null;
    }

    // [v15] aceita "25,00" (BR), "25.00" e "1.250,50" — ponto SÓ é milhar se houver vírgula
    private static string? Num(string? v)
    {
        if (string.IsNullOrWhiteSpace(v)) return null;
        v = v.Trim();
        if (v.Contains(',')) v = v.Replace(".", "").Replace(',', '.');
        return decimal.Parse(v, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture)
            .ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>[ETAPA 5] Salvar edição de produto → enfileira para a loja aplicar.</summary>
    public async Task<IActionResult> OnPostSalvarAsync(int codigo, string descricao, string prVenda,
        string? prVendaDelivery, int? grupo, string? ativo, string? descLonga)
    {
        if (!PodeEditar) { MsgErro = "Seu usuário não tem permissão para editar produtos."; return RedirectToPage(new { f = F, pg = Pg }); }
        var cnpj = await CnpjAsync();
        if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        try
        {
            var dados = new Dictionary<string, string?>
            {
                ["DESCRICAO"] = (descricao ?? "").Trim(),
                ["PR_VENDA"] = Num(prVenda),
                ["PR_VENDA_DELIVERY"] = Num(prVendaDelivery),
                ["ATIVO"] = ativo == "S" ? "S" : "N",
                ["DESCRICAO_LONGA"] = string.IsNullOrWhiteSpace(descLonga) ? null : descLonga.Trim(),
            };
            if (grupo is > 0) dados["GRUPO"] = grupo.Value.ToString();
            await _sync.EnfileirarAsync(cnpj, "PRODUTOS", codigo.ToString(), "U", dados,
                User.Identity?.Name ?? "portal");
            Msg = $"Alteração do produto {codigo} enviada — a loja aplica em ~1 minuto (acompanhe no quadro Envios).";
        }
        catch (Exception ex) { MsgErro = "Não foi possível enviar: " + ex.Message; }
        return RedirectToPage(new { f = F, pg = Pg });
    }

    /// <summary>[ETAPA 5] Novo produto → enfileira INSERT (o código é gerado NA LOJA).</summary>
    public async Task<IActionResult> OnPostNovoAsync(string descricao, string prVenda,
        string? prVendaDelivery, int? grupo)
    {
        if (!PodeEditar) { MsgErro = "Seu usuário não tem permissão para criar produtos."; return RedirectToPage(); }
        var cnpj = await CnpjAsync();
        if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        if (string.IsNullOrWhiteSpace(descricao) || Num(prVenda) is null or "0")
        { MsgErro = "Informe descrição e preço de venda."; return RedirectToPage(); }
        try
        {
            var dados = new Dictionary<string, string?>
            {
                ["EMPRESA"] = "1",
                ["DESCRICAO"] = descricao.Trim(),
                ["PR_VENDA"] = Num(prVenda),
                ["PR_VENDA_DELIVERY"] = Num(prVendaDelivery),
                ["ATIVO"] = "S",
            };
            if (grupo is > 0) dados["GRUPO"] = grupo.Value.ToString();
            await _sync.EnfileirarAsync(cnpj, "PRODUTOS", null, "I", dados, User.Identity?.Name ?? "portal");
            Msg = "Produto novo enviado — a loja cria e devolve o código em ~1 minuto. " +
                  "Lembre: ele nasce SEM dados fiscais (complete no sistema da loja antes de emitir nota).";
        }
        catch (Exception ex) { MsgErro = "Não foi possível enviar: " + ex.Message; }
        return RedirectToPage(new { f = F, pg = Pg });
    }

    /// <summary>[FASE 2 — TRAVA DUPLA] Edição dos campos FISCAIS do produto.
    /// Exige permissão ADM:FISCAL + checkbox de confirmação; a loja valida NCM na
    /// tabela mestre e só aplica com o marcador _FISCAL_CONFIRMADO (7.6.179+).</summary>
    public bool PodeFiscal => Permissao.Tem(User, "ADM:FISCAL");

    public async Task<IActionResult> OnPostSalvarFiscalAsync(int codigo, string? ncm, string? cfop,
        string? csticms, string? csosn, string? cest, string? confirmo)
    {
        if (!PodeFiscal) { MsgErro = "Seu usuário não tem a permissão FISCAL."; return RedirectToPage(new { f = F, pg = Pg }); }
        if (confirmo != "S")
        { MsgErro = "Alteração fiscal exige marcar a confirmação."; return RedirectToPage(new { f = F, pg = Pg }); }
        var cnpj = await CnpjAsync();
        if (cnpj == null) { MsgErro = "Loja não encontrada."; return RedirectToPage(); }
        try
        {
            var dados = new Dictionary<string, string?>
            {
                ["NCM"] = (ncm ?? "").Trim(),
                ["CFOP"] = (cfop ?? "").Trim(),
                ["CSTICMS"] = (csticms ?? "").Trim(),
                ["CSOSN"] = (csosn ?? "").Trim(),
                ["CEST"] = (cest ?? "").Trim(),
                ["_FISCAL_CONFIRMADO"] = "S",
            };
            await _sync.EnfileirarAsync(cnpj, "PRODUTOS", codigo.ToString(), "U", dados,
                User.Identity?.Name ?? "portal");
            Msg = $"Alteração FISCAL do produto {codigo} enviada — a loja valida (NCM na tabela mestre, " +
                  "CFOP 4 dígitos) e aplica em ~1 minuto (requer loja na 7.6.179+).";
        }
        catch (Exception ex) { MsgErro = "Não foi possível enviar: " + ex.Message; }
        return RedirectToPage(new { f = F, pg = Pg });
    }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true")) return RedirectToPage("/Admin/Index");
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null) { Aviso = "Loja não encontrada."; return Page(); }

        Status = await _sync.StatusTipadoAsync(cliente.Cnpj);
        if (Status == null || Status.CargaFeita != "S")
        {
            Aviso = "A sincronização desta loja ainda não foi ativada. " +
                    "Os cadastros aparecem aqui depois da primeira carga (fale com o suporte).";
            return Page();
        }

        if (Pg < 1) Pg = 1;
        (Total, Itens) = await _sync.ListarProdutosAsync(cliente.Cnpj, F, Pg);
        if (PodeEditar)
        {
            Grupos = await _sync.ListarGruposAsync(cliente.Cnpj);
            Fila = await _sync.FilaResumoAsync(cliente.Cnpj);
            FilaUltimas = await _sync.FilaUltimasAsync(cliente.Cnpj);
        }
        return Page();
    }
}
