using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>[ETAPA 3 — Retaguarda Web] Cadastros → Promoções (somente leitura, da réplica).</summary>
[Authorize]
public class CadPromocoesModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public CadPromocoesModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public string Loja { get; private set; } = "";
    [BindProperty(SupportsGet = true)] public string? F { get; set; }
    public List<SyncStore.PromocaoReplica> Itens { get; private set; } = new();
    public SyncStore.ReplicaStatus? Status { get; private set; }
    public string? Aviso { get; private set; }

    public static string Situacao(SyncStore.PromocaoReplica p)
    {
        if (p.Ativo == "N") return "Inativa";
        var hoje = DateTime.Today;
        if (p.DataFinal.Date < hoje) return "Encerrada";
        if (p.DataInicial.Date > hoje) return "Futura";
        return "VIGENTE";
    }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true")) return RedirectToPage("/Admin/Index");
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null) { Aviso = "Loja não encontrada."; return Page(); }

        Status = await _sync.StatusTipadoAsync(cliente.Cnpj);
        if (Status == null || Status.CargaFeita != "S")
        {
            Aviso = "A sincronização desta loja ainda não foi ativada. " +
                    "Os cadastros aparecem aqui depois da primeira carga (fale com o suporte).";
            return Page();
        }

        Itens = await _sync.ListarPromocoesAsync(cliente.Cnpj, F);
        return Page();
    }
}
