using InfoSistemas.Portal.Data;
using InfoSistemas.Portal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoSistemas.Portal.Pages;

/// <summary>
/// [ETAPA 3 — Retaguarda Web] Cadastros → Produtos (SOMENTE LEITURA nesta fase).
/// Lê a RÉPLICA `sync_&lt;cnpj&gt;` — funciona mesmo com a loja fechada/offline,
/// mostrando "dados atualizados em …". A edição chega na Etapa 5.
/// </summary>
[Authorize]
public class CadProdutosModel : PageModel
{
    private readonly Db _db;
    private readonly SyncStore _sync;
    public CadProdutosModel(Db db, SyncStore sync) { _db = db; _sync = sync; }

    public string Loja { get; private set; } = "";
    [BindProperty(SupportsGet = true)] public string? F { get; set; }
    [BindProperty(SupportsGet = true)] public int Pg { get; set; } = 1;
    public int Total { get; private set; }
    public int Paginas => Math.Max(1, (int)Math.Ceiling(Total / 50.0));
    public List<SyncStore.ProdutoReplica> Itens { get; private set; } = new();
    public SyncStore.ReplicaStatus? Status { get; private set; }
    public string? Aviso { get; private set; }

    public async Task<IActionResult> OnGetAsync()
    {
        if (User.HasClaim("is_admin", "true")) return RedirectToPage("/Admin/Index");
        Loja = User.FindFirst("razao")?.Value ?? "Sua loja";

        var clienteId = int.TryParse(User.FindFirst("cliente_id")?.Value, out var id) ? id : 0;
        var cliente = clienteId > 0 ? await _db.ObterClienteAsync(clienteId) : null;
        if (cliente == null) { Aviso = "Loja não encontrada."; return Page(); }

        Status = await _sync.StatusTipadoAsync(cliente.Cnpj);
        if (Status == null || Status.CargaFeita != "S")
        {
            Aviso = "A sincronização desta loja ainda não foi ativada. " +
                    "Os cadastros aparecem aqui depois da primeira carga (fale com o suporte).";
            return Page();
        }

        if (Pg < 1) Pg = 1;
        (Total, Itens) = await _sync.ListarProdutosAsync(cliente.Cnpj, F, Pg);
        return Page();
    }
}
