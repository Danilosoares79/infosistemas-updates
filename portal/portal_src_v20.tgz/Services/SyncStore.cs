using System.Text.Json;
using System.Text.RegularExpressions;
using Dapper;
using InfoSistemas.Portal.Data;
using MySqlConnector;

namespace InfoSistemas.Portal.Services;

// ════════════════════════════════════════════════════════════════════════
//  [ETAPA 2 — Retaguarda Web] Armazém da RÉPLICA por cliente no MySQL.
//
//  Cada cliente tem um schema `sync_<cnpj>` com o espelho das tabelas de
//  cadastro da loja (criadas a partir da estrutura ENVIADA pela própria
//  loja) + SYNC_STATUS. Tudo aqui é DERIVADO: o dado oficial é o Firebird
//  da loja. Segurança: nomes de tabela/coluna e tipos validados por regex
//  (nunca interpolamos texto livre no SQL).
// ════════════════════════════════════════════════════════════════════════
public class SyncStore
{
    private readonly string _cs;
    private readonly Db _db;
    private readonly ILogger<SyncStore> _log;

    public SyncStore(IConfiguration cfg, Db db, ILogger<SyncStore> log)
    {
        _db = db; _log = log;
        _cs = Environment.GetEnvironmentVariable("PORTAL_DB")
              ?? cfg.GetConnectionString("Portal")
              ?? "Server=mysql;Port=3306;Database=portal_relatorios;Uid=portal;Pwd=portal;";
    }

    private static readonly Regex RxNome = new("^[A-Z][A-Z0-9_]{0,47}$", RegexOptions.Compiled);
    private static readonly Regex RxTipo = new(
        @"^(INT|BIGINT|DOUBLE|DATE|TIME|DATETIME\(3\)|MEDIUMTEXT|VARCHAR\(\d{1,4}\)|CHAR\(\d{1,3}\)|DECIMAL\(\d{1,2},\d{1,2}\))$",
        RegexOptions.Compiled);

    public static string SchemaDe(string cnpj) => "sync_" + new string(cnpj.Where(char.IsDigit).ToArray());

    /// <summary>Valida cnpj + chave de ativação contra o cadastro do portal.</summary>
    public async Task<bool> AutenticarLojaAsync(string cnpj, string chave)
    {
        if (string.IsNullOrWhiteSpace(cnpj) || string.IsNullOrWhiteSpace(chave)) return false;
        var cli = await _db.ObterPorCnpjAsync(new string(cnpj.Where(char.IsDigit).ToArray()));
        return cli != null && cli.Ativo &&
               string.Equals(cli.ChaveAtivacao?.Trim(), chave.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private MySqlConnection Abrir() { var c = new MySqlConnection(_cs); c.Open(); return c; }

    // ── Schema / tabelas ─────────────────────────────────────────────────
    public async Task GarantirSchemaAsync(string cnpj)
    {
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        await c.ExecuteAsync($"CREATE DATABASE IF NOT EXISTS `{schema}` DEFAULT CHARSET=utf8mb4");
        await c.ExecuteAsync($"""
            CREATE TABLE IF NOT EXISTS `{schema}`.`SYNC_STATUS` (
              ID TINYINT NOT NULL PRIMARY KEY,
              ULTIMA_SEQ BIGINT NOT NULL DEFAULT 0,
              ULTIMA_SYNC DATETIME NULL,
              CARGA_FEITA CHAR(1) NOT NULL DEFAULT 'N',
              VERSAO_LOJA VARCHAR(20) NULL
            ) ENGINE=InnoDB
            """);
        await c.ExecuteAsync($"INSERT IGNORE INTO `{schema}`.`SYNC_STATUS` (ID) VALUES (1)");
        // [v20] pausa da descida por loja (contingência)
        try { await c.ExecuteAsync($"ALTER TABLE `{schema}`.`SYNC_STATUS` ADD COLUMN PAUSADA CHAR(1) NOT NULL DEFAULT 'N'"); } catch { }

        // [ETAPA 4] fila de DESCIDA (portal → loja) + auditoria
        await c.ExecuteAsync($"""
            CREATE TABLE IF NOT EXISTS `{schema}`.`FILA_ALTERACOES` (
              ID BIGINT AUTO_INCREMENT PRIMARY KEY,
              TABELA VARCHAR(40) NOT NULL,
              PK_VALOR VARCHAR(60) NULL,
              OPERACAO CHAR(1) NOT NULL DEFAULT 'U',
              DADOS_JSON TEXT NOT NULL,
              USUARIO VARCHAR(80) NOT NULL,
              CRIADO_EM DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
              STATUS VARCHAR(12) NOT NULL DEFAULT 'PENDENTE',
              RESULTADO TEXT NULL,
              APLICADA_EM DATETIME NULL
            ) ENGINE=InnoDB
            """);
        await c.ExecuteAsync($"""
            CREATE TABLE IF NOT EXISTS `{schema}`.`AUDITORIA` (
              ID BIGINT AUTO_INCREMENT PRIMARY KEY,
              QUANDO DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
              USUARIO VARCHAR(80) NOT NULL,
              TABELA VARCHAR(40) NOT NULL,
              PK_VALOR VARCHAR(60) NULL,
              CAMPO VARCHAR(60) NOT NULL,
              VALOR_ANTIGO TEXT NULL,
              VALOR_NOVO TEXT NULL,
              ORIGEM VARCHAR(10) NOT NULL DEFAULT 'PORTAL'
            ) ENGINE=InnoDB
            """);
    }

    // ════════════════════════════════════════════════════════════════════
    //  [ETAPA 4] FILA DE DESCIDA (portal → loja) + AUDITORIA
    // ════════════════════════════════════════════════════════════════════
    public sealed record FilaItem(long Id, string Tabela, string? PkValor, string Operacao,
        string DadosJson, string Usuario, DateTime CriadoEm, string Status, string? Resultado);

    /// <summary>Enfileira uma alteração vinda do portal e grava AUDITORIA campo a campo
    /// (valor antigo lido da réplica). Retorna o ID da fila.</summary>
    public async Task<long> EnfileirarAsync(string cnpj, string tabela, string? pkValor,
        string operacao, Dictionary<string, string?> dados, string usuario)
    {
        ValidarIdent(tabela);
        await GarantirSchemaAsync(cnpj);   // [v14] cria FILA/AUDITORIA se ainda não existem
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();

        // auditoria: diffs contra a réplica (registro atual, se existir)
        IDictionary<string, object>? atual = null;
        if (!string.IsNullOrEmpty(pkValor))
            try
            {
                atual = await c.QueryFirstOrDefaultAsync(
                    $"SELECT * FROM `{schema}`.`{tabela}` WHERE `CODIGO`=@pk", new { pk = pkValor })
                    as IDictionary<string, object>;
            }
            catch { }
        foreach (var kv in dados)
        {
            var antigo = atual != null && atual.TryGetValue(kv.Key, out var va) ? va?.ToString() : null;
            if ((antigo ?? "") == (kv.Value ?? "") && atual != null) continue;   // sem mudança
            await c.ExecuteAsync($"""
                INSERT INTO `{schema}`.`AUDITORIA` (USUARIO, TABELA, PK_VALOR, CAMPO, VALOR_ANTIGO, VALOR_NOVO)
                VALUES (@u, @t, @pk, @campo, @va, @vn)
                """, new { u = usuario, t = tabela, pk = pkValor, campo = kv.Key, va = antigo, vn = kv.Value });
        }

        var json = System.Text.Json.JsonSerializer.Serialize(dados);
        return await c.ExecuteScalarAsync<long>($"""
            INSERT INTO `{schema}`.`FILA_ALTERACOES` (TABELA, PK_VALOR, OPERACAO, DADOS_JSON, USUARIO)
            VALUES (@t, @pk, @op, @j, @u); SELECT LAST_INSERT_ID();
            """, new { t = tabela, pk = pkValor, op = operacao, j = json, u = usuario });
    }

    /// <summary>Itens PENDENTES para a loja aplicar (FIFO, até 100 por ciclo).</summary>
    public async Task<List<FilaItem>> FilaPendentesAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            // [v20] descida PAUSADA → não entrega nada para a loja (fila acumula)
            var pausada = await c.ExecuteScalarAsync<string?>(
                $"SELECT PAUSADA FROM `{schema}`.`SYNC_STATUS` WHERE ID=1");
            if (pausada == "S") return new List<FilaItem>();
            return (await c.QueryAsync<FilaItem>($"""
                SELECT ID Id, TABELA Tabela, PK_VALOR PkValor, OPERACAO Operacao,
                       DADOS_JSON DadosJson, USUARIO Usuario, CRIADO_EM CriadoEm,
                       STATUS Status, RESULTADO Resultado
                FROM `{schema}`.`FILA_ALTERACOES` WHERE STATUS='PENDENTE'
                ORDER BY ID LIMIT 100
                """)).ToList();
        }
        catch { return new List<FilaItem>(); }
    }

    /// <summary>Loja reporta o resultado: APLICADA / ERRO / CONFLITO.</summary>
    public async Task MarcarFilaAsync(string cnpj, long id, string status, string? resultado)
    {
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        await c.ExecuteAsync($"""
            UPDATE `{schema}`.`FILA_ALTERACOES`
            SET STATUS=@s, RESULTADO=@r, APLICADA_EM=NOW() WHERE ID=@id
            """, new { s = status, r = resultado, id });
        if (status == "CONFLITO")
            await c.ExecuteAsync($"""
                INSERT INTO `{schema}`.`AUDITORIA` (USUARIO, TABELA, PK_VALOR, CAMPO, VALOR_ANTIGO, VALOR_NOVO, ORIGEM)
                SELECT USUARIO, TABELA, PK_VALOR, 'CONFLITO', @r, DADOS_JSON, 'LOJA'
                FROM `{schema}`.`FILA_ALTERACOES` WHERE ID=@id
                """, new { r = resultado, id });
    }

    /// <summary>Resumo da fila para as telas (pendentes/erros).</summary>
    public async Task<(int Pendentes, int Erros)> FilaResumoAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            var r = await c.QueryFirstAsync($"""
                SELECT SUM(STATUS='PENDENTE') P, SUM(STATUS IN ('ERRO','CONFLITO')) E
                FROM `{schema}`.`FILA_ALTERACOES`
                """);
            var d = (IDictionary<string, object>)r;
            return (Convert.ToInt32(d["P"] ?? 0), Convert.ToInt32(d["E"] ?? 0));
        }
        catch { return (0, 0); }
    }

    /// <summary>[v20] Pausar/retomar a descida de uma loja + estado e alerta 48h.</summary>
    public async Task DefinirPausaAsync(string cnpj, bool pausar)
    {
        await GarantirSchemaAsync(cnpj);
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        await c.ExecuteAsync($"UPDATE `{schema}`.`SYNC_STATUS` SET PAUSADA=@p WHERE ID=1",
            new { p = pausar ? "S" : "N" });
    }

    public async Task<(bool Pausada, int ErrosAntigos)> PausaEAlertaAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            var p = await c.ExecuteScalarAsync<string?>($"SELECT PAUSADA FROM `{schema}`.`SYNC_STATUS` WHERE ID=1");
            var e = await c.ExecuteScalarAsync<int>(
                $"SELECT COUNT(*) FROM `{schema}`.`FILA_ALTERACOES` " +
                "WHERE STATUS IN ('ERRO','CONFLITO') AND CRIADO_EM < NOW() - INTERVAL 48 HOUR");
            return (p == "S", e);
        }
        catch { return (false, 0); }
    }

    /// <summary>[ETAPA 5] Últimos itens da fila (feedback nas telas de edição).</summary>
    public async Task<List<FilaItem>> FilaUltimasAsync(string cnpj, int n = 10)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            return (await c.QueryAsync<FilaItem>($"""
                SELECT ID Id, TABELA Tabela, PK_VALOR PkValor, OPERACAO Operacao,
                       DADOS_JSON DadosJson, USUARIO Usuario, CRIADO_EM CriadoEm,
                       STATUS Status, RESULTADO Resultado
                FROM `{schema}`.`FILA_ALTERACOES` ORDER BY ID DESC LIMIT {n}
                """)).ToList();
        }
        catch { return new List<FilaItem>(); }
    }

    public async Task<List<(int Codigo, string Descricao)>> ListarGruposAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            return (await c.QueryAsync<(int, string)>(
                $"SELECT CODIGO, DESCRICAO FROM `{schema}`.`GRUPO` WHERE COALESCE(ATIVO,'S')<>'N' ORDER BY DESCRICAO")).ToList();
        }
        catch { return new(); }
    }

    public async Task<List<(int Codigo, int FkProduto, string Produto, decimal Preco)>> ListarItensPromocaoAsync(string cnpj, int promo)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            return (await c.QueryAsync<(int, int, string, decimal)>($"""
                SELECT i.CODIGO, i.FK_PRODUTO, COALESCE(p.DESCRICAO,'?'), COALESCE(i.PRECO_PROMOCIONAL,0)
                FROM `{schema}`.`PROMOCAO_ITEM` i
                LEFT JOIN `{schema}`.`PRODUTOS` p ON p.CODIGO = i.FK_PRODUTO
                WHERE i.FK_PROMOCAO = @pr ORDER BY 3
                """, new { pr = promo })).ToList();
        }
        catch { return new(); }
    }

    public sealed record ColunaSpec(string Nome, string Tipo);

    private static void ValidarIdent(string nome)
    { if (!RxNome.IsMatch(nome)) throw new ArgumentException($"identificador inválido: {nome}"); }

    /// <summary>Cria a tabela réplica a partir da estrutura enviada pela loja.
    /// reset=true (1ª página da carga) → recria do zero (a nuvem é derivada).</summary>
    public async Task GarantirTabelaAsync(string cnpj, string tabela, string pk,
        List<ColunaSpec> colunas, bool reset)
    {
        ValidarIdent(tabela); ValidarIdent(pk);
        if (colunas.Count == 0) throw new ArgumentException("estrutura vazia");
        foreach (var col in colunas)
        {
            ValidarIdent(col.Nome);
            if (!RxTipo.IsMatch(col.Tipo)) throw new ArgumentException($"tipo inválido: {col.Tipo}");
        }
        if (!colunas.Any(c2 => c2.Nome.Equals(pk, StringComparison.OrdinalIgnoreCase)))
            throw new ArgumentException("PK fora da estrutura");

        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        if (reset) await c.ExecuteAsync($"DROP TABLE IF EXISTS `{schema}`.`{tabela}`");
        var defs = string.Join(", ", colunas.Select(x =>
            $"`{x.Nome}` {x.Tipo} {(x.Nome.Equals(pk, StringComparison.OrdinalIgnoreCase) ? "NOT NULL" : "NULL")}"));
        await c.ExecuteAsync(
            $"CREATE TABLE IF NOT EXISTS `{schema}`.`{tabela}` ({defs}, `DATA_SYNC` DATETIME(3) NULL, PRIMARY KEY (`{pk}`)) ENGINE=InnoDB");
        _colunasCache.TryRemove((schema, tabela), out _);
    }

    // ── Upsert / delete ──────────────────────────────────────────────────
    private readonly System.Collections.Concurrent.ConcurrentDictionary<(string, string), HashSet<string>> _colunasCache = new();

    private async Task<HashSet<string>> ColunasDaTabelaAsync(MySqlConnection c, string schema, string tabela)
    {
        if (_colunasCache.TryGetValue((schema, tabela), out var cols)) return cols;
        var lista = (await c.QueryAsync<string>(
            "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@s AND TABLE_NAME=@t",
            new { s = schema, t = tabela })).ToHashSet(StringComparer.OrdinalIgnoreCase);
        _colunasCache[(schema, tabela)] = lista;
        return lista;
    }

    /// <summary>UPSERT idempotente por PK (aplicar 2x = mesmo resultado).</summary>
    public async Task UpsertAsync(string cnpj, string tabela, string pk,
        List<Dictionary<string, string?>> linhas)
    {
        if (linhas.Count == 0) return;
        ValidarIdent(tabela); ValidarIdent(pk);
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        var existentes = await ColunasDaTabelaAsync(c, schema, tabela);
        await using var tx = await c.BeginTransactionAsync();
        foreach (var linha in linhas)
        {
            var cols = linha.Keys.Where(k => RxNome.IsMatch(k) && existentes.Contains(k)).ToList();
            if (!cols.Contains(pk, StringComparer.OrdinalIgnoreCase)) continue;
            var nomes = string.Join(", ", cols.Select(k => $"`{k}`"));
            var pars  = string.Join(", ", cols.Select((k, i) => $"@p{i}"));
            var upds  = string.Join(", ", cols.Where(k => !k.Equals(pk, StringComparison.OrdinalIgnoreCase))
                                              .Select(k => $"`{k}`=nv.`{k}`"));
            var sql = $"INSERT INTO `{schema}`.`{tabela}` ({nomes}, `DATA_SYNC`) VALUES ({pars}, NOW(3)) AS nv " +
                      $"ON DUPLICATE KEY UPDATE {upds}, `DATA_SYNC`=NOW(3)";
            var dp = new DynamicParameters();
            for (int i = 0; i < cols.Count; i++) dp.Add($"p{i}", linha[cols[i]]);
            await c.ExecuteAsync(sql, dp, tx);
        }
        await tx.CommitAsync();
    }

    public async Task DeleteAsync(string cnpj, string tabela, string pk, string pkValor)
    {
        ValidarIdent(tabela); ValidarIdent(pk);
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        await c.ExecuteAsync($"DELETE FROM `{schema}`.`{tabela}` WHERE `{pk}`=@v", new { v = pkValor });
    }

    // ── Status ───────────────────────────────────────────────────────────
    public async Task AtualizarStatusAsync(string cnpj, long? seq, bool? cargaFeita, string? versaoLoja)
    {
        var schema = SchemaDe(cnpj);
        await using var c = Abrir();
        var sets = new List<string> { "ULTIMA_SYNC=NOW()" };
        var dp = new DynamicParameters();
        if (seq.HasValue) { sets.Add("ULTIMA_SEQ=@q"); dp.Add("q", seq.Value); }
        if (cargaFeita.HasValue) { sets.Add("CARGA_FEITA=@cf"); dp.Add("cf", cargaFeita.Value ? "S" : "N"); }
        if (!string.IsNullOrWhiteSpace(versaoLoja)) { sets.Add("VERSAO_LOJA=@vl"); dp.Add("vl", versaoLoja); }
        await c.ExecuteAsync($"UPDATE `{schema}`.`SYNC_STATUS` SET {string.Join(", ", sets)} WHERE ID=1", dp);
    }

    public async Task<dynamic?> StatusAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            return await c.QueryFirstOrDefaultAsync(
                $"SELECT ULTIMA_SEQ, ULTIMA_SYNC, CARGA_FEITA, VERSAO_LOJA FROM `{schema}`.`SYNC_STATUS` WHERE ID=1");
        }
        catch { return null; }
    }

    // ════════════════════════════════════════════════════════════════════
    //  [ETAPA 3] LEITURA da réplica para as telas do portal
    // ════════════════════════════════════════════════════════════════════
    public sealed record ReplicaStatus(long UltimaSeq, DateTime? UltimaSync, string CargaFeita, string? VersaoLoja);
    public sealed record ProdutoReplica(int Codigo, string Descricao, string? Grupo,
        decimal PrVenda, decimal? PrVendaDelivery, string Ativo, DateTime? UltAlteracao);
    public sealed record PromocaoReplica(int Codigo, string Descricao, DateTime DataInicial,
        DateTime DataFinal, string Ativo, string TipoDesconto, string Produtos, DateTime? UltAlteracao);

    public async Task<ReplicaStatus?> StatusTipadoAsync(string cnpj)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            return await c.QueryFirstOrDefaultAsync<ReplicaStatus>(
                $"SELECT ULTIMA_SEQ AS UltimaSeq, ULTIMA_SYNC AS UltimaSync, " +
                $"CARGA_FEITA AS CargaFeita, VERSAO_LOJA AS VersaoLoja " +
                $"FROM `{schema}`.`SYNC_STATUS` WHERE ID=1");
        }
        catch { return null; }
    }

    /// <summary>Lista paginada de produtos da RÉPLICA (busca por descrição/código/grupo).</summary>
    public async Task<(int Total, List<ProdutoReplica> Itens)> ListarProdutosAsync(
        string cnpj, string? filtro, int pagina, int porPagina = 50)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            var f = (filtro ?? "").Trim();
            var where = "WHERE 1=1";
            var dp = new DynamicParameters();
            if (f.Length > 0)
            {
                where += " AND (p.DESCRICAO LIKE @f OR g.DESCRICAO LIKE @f OR CAST(p.CODIGO AS CHAR) = @fc)";
                dp.Add("f", "%" + f + "%"); dp.Add("fc", f);
            }
            var total = await c.ExecuteScalarAsync<int>(
                $"SELECT COUNT(*) FROM `{schema}`.`PRODUTOS` p LEFT JOIN `{schema}`.`GRUPO` g ON g.CODIGO = p.GRUPO {where}", dp);
            dp.Add("lim", porPagina); dp.Add("off", Math.Max(0, pagina - 1) * porPagina);
            var itens = (await c.QueryAsync<ProdutoReplica>(
                $"""
                SELECT p.CODIGO AS Codigo, p.DESCRICAO AS Descricao, g.DESCRICAO AS Grupo,
                       COALESCE(p.PR_VENDA,0) AS PrVenda, p.PR_VENDA_DELIVERY AS PrVendaDelivery,
                       COALESCE(p.ATIVO,'S') AS Ativo, p.ULT_ALTERACAO AS UltAlteracao
                FROM `{schema}`.`PRODUTOS` p
                LEFT JOIN `{schema}`.`GRUPO` g ON g.CODIGO = p.GRUPO
                {where}
                ORDER BY p.DESCRICAO LIMIT @lim OFFSET @off
                """, dp)).ToList();
            return (total, itens);
        }
        catch { return (0, new List<ProdutoReplica>()); }
    }

    /// <summary>Promoções da RÉPLICA com os produtos participantes agregados.</summary>
    public async Task<List<PromocaoReplica>> ListarPromocoesAsync(string cnpj, string? filtro)
    {
        try
        {
            var schema = SchemaDe(cnpj);
            await using var c = Abrir();
            var f = (filtro ?? "").Trim();
            var where = "";
            var dp = new DynamicParameters();
            if (f.Length > 0)
            {
                where = "WHERE pr.DESCRICAO LIKE @f OR EXISTS (SELECT 1 FROM " +
                        $"`{schema}`.`PROMOCAO_ITEM` i2 JOIN `{schema}`.`PRODUTOS` p2 ON p2.CODIGO = i2.FK_PRODUTO " +
                        "WHERE i2.FK_PROMOCAO = pr.CODIGO AND p2.DESCRICAO LIKE @f)";
                dp.Add("f", "%" + f + "%");
            }
            return (await c.QueryAsync<PromocaoReplica>(
                $"""
                SELECT pr.CODIGO AS Codigo, pr.DESCRICAO AS Descricao,
                       pr.DATA_INICIAL AS DataInicial, pr.DATA_FINAL AS DataFinal,
                       COALESCE(pr.ATIVO,'S') AS Ativo, COALESCE(pr.TIPO_DESCONTO,'F') AS TipoDesconto,
                       COALESCE((SELECT GROUP_CONCAT(
                                    CONCAT(p.DESCRICAO, ' — De: R$ ', FORMAT(COALESCE(p.PR_VENDA,0), 2, 'pt_BR'),
                                           '  Por: R$ ', FORMAT(COALESCE(i.PRECO_PROMOCIONAL,0), 2, 'pt_BR'))
                                    ORDER BY p.DESCRICAO SEPARATOR ' · ')
                                 FROM `{schema}`.`PROMOCAO_ITEM` i
                                 JOIN `{schema}`.`PRODUTOS` p ON p.CODIGO = i.FK_PRODUTO
                                 WHERE i.FK_PROMOCAO = pr.CODIGO), '') AS Produtos,
                       pr.ULT_ALTERACAO AS UltAlteracao
                FROM `{schema}`.`PROMOCAO` pr
                {where}
                ORDER BY pr.DATA_FINAL DESC, pr.DESCRICAO
                """, dp)).ToList();
        }
        catch { return new List<PromocaoReplica>(); }
    }
}
